import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { salaries } from "@db/schema";
import { eq, desc, gte, lte, and } from "drizzle-orm";

export const salariesRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(salaries).orderBy(desc(salaries.createdAt));
  }),

  create: publicQuery
    .input(
      z.object({
        employeeName: z.string().min(1),
        amount: z.number(),
        month: z.string(),
        year: z.number(),
        description: z.string().optional(),
        date: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(salaries).values({ ...input, createdBy: 1 });
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        employeeName: z.string().min(1).optional(),
        amount: z.number().optional(),
        month: z.string().optional(),
        year: z.number().optional(),
        description: z.string().optional(),
        date: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(salaries).set(data).where(eq(salaries.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(salaries).where(eq(salaries.id, input.id));
    return { success: true };
  }),

  filter: publicQuery
    .input(z.object({ fromDate: z.string().optional(), toDate: z.string().optional(), month: z.string().optional(), year: z.number().optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.fromDate) conditions.push(gte(salaries.date, new Date(input.fromDate)));
      if (input.toDate) conditions.push(lte(salaries.date, new Date(input.toDate)));
      if (input.month) conditions.push(eq(salaries.month, input.month));
      if (input.year) conditions.push(eq(salaries.year, input.year));

      if (conditions.length > 0) {
        return db.select().from(salaries).where(and(...conditions)).orderBy(desc(salaries.createdAt));
      }
      return db.select().from(salaries).orderBy(desc(salaries.createdAt));
    }),
});
