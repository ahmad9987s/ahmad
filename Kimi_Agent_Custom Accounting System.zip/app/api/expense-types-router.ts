import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { expenseTypes } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const expenseTypesRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(expenseTypes).orderBy(desc(expenseTypes.createdAt));
  }),

  active: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(expenseTypes).where(eq(expenseTypes.isActive, true)).orderBy(expenseTypes.name);
  }),

  create: publicQuery
    .input(z.object({ name: z.string().min(1), description: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(expenseTypes).values(input);
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(z.object({ id: z.number(), name: z.string().min(1).optional(), description: z.string().optional(), isActive: z.boolean().optional() }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(expenseTypes).set(data).where(eq(expenseTypes.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(expenseTypes).where(eq(expenseTypes.id, input.id));
    return { success: true };
  }),
});
