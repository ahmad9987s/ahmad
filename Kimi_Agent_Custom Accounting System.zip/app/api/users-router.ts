import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { users } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import bcrypt from "bcryptjs";

export const usersRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const allUsers = await db.select().from(users).orderBy(desc(users.createdAt));
    return allUsers.map((u: { id: number; username: string; displayName: string; role: string; isActive: boolean; createdAt: Date }) => ({
      id: u.id,
      username: u.username,
      displayName: u.displayName,
      role: u.role,
      isActive: u.isActive,
      createdAt: u.createdAt,
    }));
  }),

  create: publicQuery
    .input(
      z.object({
        username: z.string().min(3),
        password: z.string().min(4),
        displayName: z.string().min(1),
        role: z.enum(["admin", "manager", "cashier"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const hashedPassword = await bcrypt.hash(input.password, 10);
      const [result] = await db.insert(users).values({
        ...input,
        password: hashedPassword,
      });
      return { id: Number(result.insertId), username: input.username, displayName: input.displayName, role: input.role };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        username: z.string().min(3).optional(),
        displayName: z.string().min(1).optional(),
        role: z.enum(["admin", "manager", "cashier"]).optional(),
        isActive: z.boolean().optional(),
        password: z.string().min(4).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, password, ...data } = input;
      const db = getDb();

      const updateData: Record<string, unknown> = { ...data };
      if (password) {
        updateData.password = await bcrypt.hash(password, 10);
      }

      await db.update(users).set(updateData).where(eq(users.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(users).where(eq(users.id, input.id));
    return { success: true };
  }),
});
