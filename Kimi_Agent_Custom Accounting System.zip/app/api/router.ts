import { createRouter, publicQuery } from "./middleware";
import { localAuthRouter } from "./local-auth-router";
import { settingsRouter } from "./settings-router";
import { saleTypesRouter } from "./sale-types-router";
import { expenseTypesRouter } from "./expense-types-router";
import { suppliersRouter } from "./suppliers-router";
import { productsRouter } from "./products-router";
import { invoicesRouter } from "./invoices-router";
import { purchasesRouter } from "./purchases-router";
import { expensesRouter } from "./expenses-router";
import { salariesRouter } from "./salaries-router";
import { debtsRouter } from "./debt-router";
import { bankTransfersRouter } from "./bank-transfers-router";
import { usersRouter } from "./users-router";
import { dashboardRouter } from "./dashboard-router";
import { profitRouter } from "./profit-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  localAuth: localAuthRouter,
  settings: settingsRouter,
  saleTypes: saleTypesRouter,
  expenseTypes: expenseTypesRouter,
  suppliers: suppliersRouter,
  products: productsRouter,
  invoices: invoicesRouter,
  purchases: purchasesRouter,
  expenses: expensesRouter,
  salaries: salariesRouter,
  debts: debtsRouter,
  bankTransfers: bankTransfersRouter,
  users: usersRouter,
  dashboard: dashboardRouter,
  profit: profitRouter,
});

export type AppRouter = typeof appRouter;
