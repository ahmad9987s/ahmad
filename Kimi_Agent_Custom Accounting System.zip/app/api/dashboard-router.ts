import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { invoices, purchases, expenses, salaries, debts } from "@db/schema";
import { gte } from "drizzle-orm";

export const dashboardRouter = createRouter({
  stats: publicQuery.query(async () => {
    const db = getDb();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    // Today's sales
    const todayInvoices = await db.select().from(invoices).where(gte(invoices.createdAt, today));
    const todaySales = todayInvoices.reduce((sum: number, inv: { total: string | number }) => sum + Number(inv.total), 0);

    // Today's purchases
    const todayPurchases = await db.select().from(purchases).where(gte(purchases.createdAt, today));
    const todayPurchasesTotal = todayPurchases.reduce((sum: number, p: { total: string | number }) => sum + Number(p.total), 0);

    // Today's expenses
    const todayExpenses = await db.select().from(expenses).where(gte(expenses.createdAt, today));
    const todayExpensesTotal = todayExpenses.reduce((sum: number, e: { amount: string | number }) => sum + Number(e.amount), 0);

    // Month sales
    const monthInvoices = await db.select().from(invoices).where(gte(invoices.createdAt, firstDayOfMonth));
    const monthSales = monthInvoices.reduce((sum: number, inv: { total: string | number }) => sum + Number(inv.total), 0);

    // Month purchases
    const monthPurchases = await db.select().from(purchases).where(gte(purchases.createdAt, firstDayOfMonth));
    const monthPurchasesTotal = monthPurchases.reduce((sum: number, p: { total: string | number }) => sum + Number(p.total), 0);

    // Month expenses
    const monthExpenses = await db.select().from(expenses).where(gte(expenses.createdAt, firstDayOfMonth));
    const monthExpensesTotal = monthExpenses.reduce((sum: number, e: { amount: string | number }) => sum + Number(e.amount), 0);

    // Month salaries
    const monthSalaries = await db.select().from(salaries).where(gte(salaries.createdAt, firstDayOfMonth));
    const monthSalariesTotal = monthSalaries.reduce((sum: number, s: { amount: string | number }) => sum + Number(s.amount), 0);

    // Pending debts
    const allDebts = await db.select().from(debts);
    const pendingDebts = allDebts.filter((d: { isPaid: boolean | null }) => !d.isPaid);
    const pendingDebtsTotal = pendingDebts.reduce((sum: number, d: { remaining: string | number }) => sum + Number(d.remaining), 0);

    // Invoice count
    const allInvoices = await db.select().from(invoices);

    return {
      today: {
        sales: todaySales,
        purchases: todayPurchasesTotal,
        expenses: todayExpensesTotal,
        net: todaySales - todayPurchasesTotal - todayExpensesTotal,
      },
      month: {
        sales: monthSales,
        purchases: monthPurchasesTotal,
        expenses: monthExpensesTotal,
        salaries: monthSalariesTotal,
        net: monthSales - monthPurchasesTotal - monthExpensesTotal - monthSalariesTotal,
      },
      pendingDebts: pendingDebtsTotal,
      recentInvoices: allInvoices.slice(0, 10),
    };
  }),

  chartData: publicQuery.query(async () => {
    const db = getDb();

    // Last 30 days sales
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const allInvoices = await db.select().from(invoices).where(gte(invoices.createdAt, thirtyDaysAgo));

    const salesByDay: Record<string, number> = {};
    for (const inv of allInvoices) {
      const date = (inv.createdAt as Date).toISOString().split("T")[0];
      salesByDay[date] = (salesByDay[date] || 0) + Number(inv.total);
    }

    const chartData = Object.entries(salesByDay)
      .map(([date, amount]) => ({ date, amount }))
      .sort((a, b) => a.date.localeCompare(b.date));

    return chartData;
  }),
});
