import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { purchases, products, suppliers } from "@db/schema";
import { eq, desc, gte, lte, and } from "drizzle-orm";

export const purchasesRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(purchases).orderBy(desc(purchases.createdAt));
  }),

  create: publicQuery
    .input(
      z.object({
        supplierId: z.number().optional(),
        productId: z.number().optional(),
        productName: z.string().optional(),
        quantity: z.number(),
        unitPrice: z.number(),
        total: z.number(),
        paid: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(purchases).values({
        ...input,
        createdBy: 1,
      });

      // Update product stock if productId exists
      if (input.productId) {
        const [product] = await db.select().from(products).where(eq(products.id, input.productId)).limit(1);
        if (product) {
          await db
            .update(products)
            .set({ stock: Number(product.stock) + input.quantity })
            .where(eq(products.id, input.productId));
        }
      }

      // Update supplier balance
      if (input.supplierId) {
        const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, input.supplierId)).limit(1);
        if (supplier) {
          await db
            .update(suppliers)
            .set({ balance: Number(supplier.balance) + (input.total - (input.paid || 0)) })
            .where(eq(suppliers.id, input.supplierId));
        }
      }

      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        supplierId: z.number().optional(),
        productId: z.number().optional(),
        productName: z.string().optional(),
        quantity: z.number().optional(),
        unitPrice: z.number().optional(),
        total: z.number().optional(),
        paid: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(purchases).set(data).where(eq(purchases.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(purchases).where(eq(purchases.id, input.id));
    return { success: true };
  }),

  filter: publicQuery
    .input(
      z.object({
        fromDate: z.string().optional(),
        toDate: z.string().optional(),
        supplierId: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.fromDate) conditions.push(gte(purchases.createdAt, new Date(input.fromDate)));
      if (input.toDate) conditions.push(lte(purchases.createdAt, new Date(input.toDate)));
      if (input.supplierId) conditions.push(eq(purchases.supplierId, input.supplierId));

      if (conditions.length > 0) {
        return db.select().from(purchases).where(and(...conditions)).orderBy(desc(purchases.createdAt));
      }
      return db.select().from(purchases).orderBy(desc(purchases.createdAt));
    }),
});
