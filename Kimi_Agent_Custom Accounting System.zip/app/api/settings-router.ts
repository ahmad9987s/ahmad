import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { settings } from "@db/schema";
import { eq } from "drizzle-orm";

export const settingsRouter = createRouter({
  get: publicQuery.query(async () => {
    const db = getDb();
    const [setting] = await db.select().from(settings).limit(1);
    return setting || null;
  }),

  upsert: publicQuery
    .input(
      z.object({
        shopName: z.string().min(1),
        shopAddress: z.string(),
        shopPhone1: z.string().optional(),
        shopPhone2: z.string().optional(),
        defaultDiscount: z.number().min(0).max(100).optional(),
        currency: z.string().optional(),
        taxRate: z.number().min(0).max(100).optional(),
        invoicePrefix: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [existing] = await db.select().from(settings).limit(1);

      if (existing) {
        await db
          .update(settings)
          .set({
            ...input,
            updatedAt: new Date(),
          })
          .where(eq(settings.id, existing.id));
        return { success: true, id: existing.id };
      } else {
        const [result] = await db.insert(settings).values(input);
        return { success: true, id: Number(result.insertId) };
      }
    }),
});
