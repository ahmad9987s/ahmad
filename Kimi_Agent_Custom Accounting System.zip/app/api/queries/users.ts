import { eq } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertUser } from "@db/schema";
import { getDb } from "./connection";

export async function findUserByUsername(username: string) {
  const rows = await getDb()
    .select()
    .from(schema.users)
    .where(eq(schema.users.username, username))
    .limit(1);
  return rows.at(0);
}

export async function createUser(data: InsertUser) {
  const [result] = await getDb()
    .insert(schema.users)
    .values(data);
  return result;
}

export async function upsertUser(data: Partial<InsertUser> & { username: string }) {
  const db = getDb();
  const existing = await findUserByUsername(data.username);
  if (existing) {
    await db.update(schema.users)
      .set(data)
      .where(eq(schema.users.id, existing.id));
    return existing;
  } else {
    const [result] = await db.insert(schema.users).values(data as InsertUser);
    return result;
  }
}
