import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { products } from "@db/schema";
import { eq, desc, like } from "drizzle-orm";

export const productsRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(products).orderBy(desc(products.createdAt));
  }),

  active: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(products).where(eq(products.isActive, true)).orderBy(products.name);
  }),

  search: publicQuery
    .input(z.object({ query: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(products)
        .where(like(products.name, `%${input.query}%`))
        .orderBy(products.name);
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        category: z.string().optional(),
        unit: z.string().optional(),
        costPrice: z.number().optional(),
        sellPrice: z.number().optional(),
        stock: z.number().optional(),
        supplierId: z.number().optional(),
        barcode: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(products).values(input);
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        category: z.string().optional(),
        unit: z.string().optional(),
        costPrice: z.number().optional(),
        sellPrice: z.number().optional(),
        stock: z.number().optional(),
        supplierId: z.number().optional(),
        barcode: z.string().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(products).set(data).where(eq(products.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(products).where(eq(products.id, input.id));
    return { success: true };
  }),
});
