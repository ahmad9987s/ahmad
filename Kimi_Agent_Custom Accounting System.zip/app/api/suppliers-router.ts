import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { suppliers } from "@db/schema";
import { eq, desc, like, or } from "drizzle-orm";

export const suppliersRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(suppliers).orderBy(desc(suppliers.createdAt));
  }),

  search: publicQuery
    .input(z.object({ query: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(suppliers)
        .where(
          or(
            like(suppliers.name, `%${input.query}%`),
            like(suppliers.phone || "", `%${input.query}%`)
          )
        )
        .orderBy(suppliers.name);
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        phone: z.string().optional(),
        email: z.string().optional(),
        address: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(suppliers).values(input);
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        address: z.string().optional(),
        notes: z.string().optional(),
        balance: z.number().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(suppliers).set(data).where(eq(suppliers.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(suppliers).where(eq(suppliers.id, input.id));
    return { success: true };
  }),
});
