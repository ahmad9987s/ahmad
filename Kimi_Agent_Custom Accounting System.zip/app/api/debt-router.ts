import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { debts, debtPayments } from "@db/schema";
import { eq, desc, gte, lte, and } from "drizzle-orm";

export const debtsRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const allDebts = await db.select().from(debts).orderBy(desc(debts.createdAt));
    const result = [];
    for (const debt of allDebts) {
      const payments = await db.select().from(debtPayments).where(eq(debtPayments.debtId, debt.id));
      result.push({ ...debt, payments });
    }
    return result;
  }),

  create: publicQuery
    .input(
      z.object({
        personName: z.string().min(1),
        phone: z.string().optional(),
        amount: z.number(),
        type: z.enum(["customer", "supplier", "other"]).optional(),
        notes: z.string().optional(),
        dueDate: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(debts).values({
        ...input,
        remaining: input.amount,
        createdBy: 1,
      });
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        personName: z.string().min(1).optional(),
        phone: z.string().optional(),
        amount: z.number().optional(),
        type: z.enum(["customer", "supplier", "other"]).optional(),
        notes: z.string().optional(),
        dueDate: z.string().optional(),
        isPaid: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(debts).set(data).where(eq(debts.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(debtPayments).where(eq(debtPayments.debtId, input.id));
    await db.delete(debts).where(eq(debts.id, input.id));
    return { success: true };
  }),

  addPayment: publicQuery
    .input(
      z.object({
        debtId: z.number(),
        amount: z.number(),
        paymentDate: z.string(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(debtPayments).values({ ...input, createdBy: 1 });

      // Update debt
      const [debt] = await db.select().from(debts).where(eq(debts.id, input.debtId)).limit(1);
      if (debt) {
        const newPaid = Number(debt.paid) + input.amount;
        const newRemaining = Number(debt.amount) - newPaid;
        await db
          .update(debts)
          .set({
            paid: newPaid,
            remaining: newRemaining,
            isPaid: newRemaining <= 0,
          })
          .where(eq(debts.id, input.debtId));
      }

      return { id: Number(result.insertId), ...input };
    }),
});
