import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { invoices, invoiceItems, settings } from "@db/schema";
import { eq, desc, like, gte, lte, and } from "drizzle-orm";

export const invoicesRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(invoices).orderBy(desc(invoices.createdAt));
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [invoice] = await db.select().from(invoices).where(eq(invoices.id, input.id)).limit(1);
      if (!invoice) return null;
      const items = await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, input.id));
      return { ...invoice, items };
    }),

  getByNumber: publicQuery
    .input(z.object({ number: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [invoice] = await db.select().from(invoices).where(eq(invoices.invoiceNumber, input.number)).limit(1);
      if (!invoice) return null;
      const items = await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoice.id));
      return { ...invoice, items };
    }),

  create: publicQuery
    .input(
      z.object({
        customerName: z.string().optional(),
        customerPhone: z.string().optional(),
        saleTypeId: z.number().optional(),
        paymentMethod: z.enum(["cash", "bank", "credit"]).optional(),
        subtotal: z.number(),
        discount: z.number().optional(),
        tax: z.number().optional(),
        total: z.number(),
        paid: z.number().optional(),
        remaining: z.number().optional(),
        notes: z.string().optional(),
        items: z.array(
          z.object({
            productId: z.number().optional(),
            productName: z.string(),
            quantity: z.number(),
            unitPrice: z.number(),
            discount: z.number().optional(),
            total: z.number(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { items, ...invoiceData } = input;

      // Get next invoice number
      const [setting] = await db.select().from(settings).limit(1);
      const prefix = setting?.invoicePrefix || "INV";
      const nextNum = setting?.nextInvoiceNumber || 1;
      const invoiceNumber = `${prefix}-${String(nextNum).padStart(3, "0")}`;

      // Update next invoice number
      if (setting) {
        await db
          .update(settings)
          .set({ nextInvoiceNumber: (setting.nextInvoiceNumber || 1) + 1 })
          .where(eq(settings.id, setting.id));
      }

      // Create invoice
      const [result] = await db.insert(invoices).values({
        ...invoiceData,
        invoiceNumber,
        createdBy: 1, // TODO: get from auth context
      });

      const invoiceId = Number(result.insertId);

      // Create invoice items
      if (items && items.length > 0) {
        await db.insert(invoiceItems).values(
          items.map((item) => ({ ...item, invoiceId }))
        );
      }

      return { id: invoiceId, invoiceNumber };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        customerName: z.string().optional(),
        customerPhone: z.string().optional(),
        saleTypeId: z.number().optional(),
        paymentMethod: z.enum(["cash", "bank", "credit"]).optional(),
        subtotal: z.number().optional(),
        discount: z.number().optional(),
        tax: z.number().optional(),
        total: z.number().optional(),
        paid: z.number().optional(),
        remaining: z.number().optional(),
        notes: z.string().optional(),
        items: z
          .array(
            z.object({
              productId: z.number().optional(),
              productName: z.string(),
              quantity: z.number(),
              unitPrice: z.number(),
              discount: z.number().optional(),
              total: z.number(),
            })
          )
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, items, ...data } = input;

      await db.update(invoices).set(data).where(eq(invoices.id, id));

      if (items && items.length > 0) {
        // Delete old items
        await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, id));
        // Insert new items
        await db.insert(invoiceItems).values(items.map((item) => ({ ...item, invoiceId: id })));
      }

      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      // Delete items first
      await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, input.id));
      // Delete invoice
      await db.delete(invoices).where(eq(invoices.id, input.id));
      return { success: true };
    }),

  filter: publicQuery
    .input(
      z.object({
        fromDate: z.string().optional(),
        toDate: z.string().optional(),
        paymentMethod: z.string().optional(),
        customerName: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input.fromDate) {
        conditions.push(gte(invoices.createdAt, new Date(input.fromDate)));
      }
      if (input.toDate) {
        conditions.push(lte(invoices.createdAt, new Date(input.toDate)));
      }
      if (input.paymentMethod) {
        conditions.push(eq(invoices.paymentMethod, input.paymentMethod as "cash" | "bank" | "credit"));
      }
      if (input.customerName) {
        conditions.push(like(invoices.customerName || "", `%${input.customerName}%`));
      }

      if (conditions.length > 0) {
        return db
          .select()
          .from(invoices)
          .where(and(...conditions))
          .orderBy(desc(invoices.createdAt));
      }

      return db.select().from(invoices).orderBy(desc(invoices.createdAt));
    }),
});
