import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { expenses } from "@db/schema";
import { eq, desc, gte, lte, and } from "drizzle-orm";

export const expensesRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(expenses).orderBy(desc(expenses.createdAt));
  }),

  create: publicQuery
    .input(
      z.object({
        expenseTypeId: z.number().optional(),
        amount: z.number(),
        description: z.string().optional(),
        date: z.string(),
        receiptNumber: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(expenses).values({
        ...input,
        createdBy: 1,
      });
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        expenseTypeId: z.number().optional(),
        amount: z.number().optional(),
        description: z.string().optional(),
        date: z.string().optional(),
        receiptNumber: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(expenses).set(data).where(eq(expenses.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(expenses).where(eq(expenses.id, input.id));
    return { success: true };
  }),

  filter: publicQuery
    .input(z.object({ fromDate: z.string().optional(), toDate: z.string().optional(), expenseTypeId: z.number().optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.fromDate) conditions.push(gte(expenses.date, new Date(input.fromDate)));
      if (input.toDate) conditions.push(lte(expenses.date, new Date(input.toDate)));
      if (input.expenseTypeId) conditions.push(eq(expenses.expenseTypeId, input.expenseTypeId));

      if (conditions.length > 0) {
        return db.select().from(expenses).where(and(...conditions)).orderBy(desc(expenses.createdAt));
      }
      return db.select().from(expenses).orderBy(desc(expenses.createdAt));
    }),
});
