import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { users, settings } from "@db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "abdo-accounting-secret-key-2026"
);

export async function createToken(payload: { userId: number; role: string }) {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("7d")
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET, { clockTolerance: 60 });
    return payload as { userId: number; role: string };
  } catch {
    return null;
  }
}

export const localAuthRouter = createRouter({
  // تسجيل الدخول
  login: publicQuery
    .input(
      z.object({
        username: z.string().min(1),
        password: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.username, input.username))
        .limit(1);

      if (!user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "اسم المستخدم أو كلمة المرور غير صحيحة",
        });
      }

      if (!user.isActive) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "الحساب غير مفعل",
        });
      }

      const valid = await bcrypt.compare(input.password, user.password);
      if (!valid) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "اسم المستخدم أو كلمة المرور غير صحيحة",
        });
      }

      const token = await createToken({ userId: user.id, role: user.role });

      return {
        token,
        user: {
          id: user.id,
          username: user.username,
          displayName: user.displayName,
          role: user.role,
        },
      };
    }),

  // التحقق من التوكن
  me: publicQuery.query(async ({ ctx }) => {
    const authHeader = ctx.req.headers.get("x-auth-token");
    if (!authHeader) return null;

    const payload = await verifyToken(authHeader);
    if (!payload) return null;

    const db = getDb();
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, payload.userId))
      .limit(1);

    if (!user || !user.isActive) return null;

    return {
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      role: user.role,
    };
  }),

  // إنشاء مستخدم أولي
  seed: publicQuery.mutation(async () => {
    const db = getDb();
    const [existing] = await db.select().from(users).limit(1);
    if (existing) return { message: "Users already exist" };

    const hashedPassword = await bcrypt.hash("admin", 10);
    await db.insert(users).values({
      username: "admin",
      password: hashedPassword,
      displayName: "مدير النظام",
      role: "admin",
    });

    await db.insert(settings).values({
      shopName: "ABDO",
      shopAddress: "أريحا - وسط البلد - شارع البنوك",
    });

    return { message: "Initial user created" };
  }),
});
