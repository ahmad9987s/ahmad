import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { invoices, purchases, expenses, salaries } from "@db/schema";
import { gte, lte, and } from "drizzle-orm";

export const profitRouter = createRouter({
  report: publicQuery
    .input(
      z.object({
        fromDate: z.string().optional(),
        toDate: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const now = new Date();
      const fromDate = input.fromDate ? new Date(input.fromDate) : new Date(now.getFullYear(), now.getMonth(), 1);
      const toDate = input.toDate ? new Date(input.toDate) : now;

      const dateFilter = and(gte(invoices.createdAt, fromDate), lte(invoices.createdAt, toDate));
      const purchaseDateFilter = and(gte(purchases.createdAt, fromDate), lte(purchases.createdAt, toDate));
      const expenseDateFilter = and(gte(expenses.createdAt, fromDate), lte(expenses.createdAt, toDate));
      const salaryDateFilter = and(gte(salaries.createdAt, fromDate), lte(salaries.createdAt, toDate));

      // Total Sales
      const allInvoices = await db.select().from(invoices).where(dateFilter);
      const totalSales = allInvoices.reduce((sum: number, inv: { total: string | number }) => sum + Number(inv.total), 0);
      const totalDiscounts = allInvoices.reduce((sum: number, inv: { discount: string | number | null }) => sum + Number(inv.discount || 0), 0);

      // Total Purchases
      const allPurchases = await db.select().from(purchases).where(purchaseDateFilter);
      const totalPurchases = allPurchases.reduce((sum: number, p: { total: string | number }) => sum + Number(p.total), 0);

      // Total Expenses
      const allExpenses = await db.select().from(expenses).where(expenseDateFilter);
      const totalExpenses = allExpenses.reduce((sum: number, e: { amount: string | number }) => sum + Number(e.amount), 0);

      // Total Salaries
      const allSalaries = await db.select().from(salaries).where(salaryDateFilter);
      const totalSalaries = allSalaries.reduce((sum: number, s: { amount: string | number }) => sum + Number(s.amount), 0);

      // Net Profit
      const netProfit = totalSales - totalPurchases - totalExpenses - totalSalaries;

      // Sales by payment method
      const cashSales = allInvoices.filter((inv: { paymentMethod: string }) => inv.paymentMethod === "cash").reduce((sum: number, inv: { total: string | number }) => sum + Number(inv.total), 0);
      const bankSales = allInvoices.filter((inv: { paymentMethod: string }) => inv.paymentMethod === "bank").reduce((sum: number, inv: { total: string | number }) => sum + Number(inv.total), 0);
      const creditSales = allInvoices.filter((inv: { paymentMethod: string }) => inv.paymentMethod === "credit").reduce((sum: number, inv: { total: string | number }) => sum + Number(inv.total), 0);

      return {
        summary: {
          totalSales,
          totalDiscounts,
          totalPurchases,
          totalExpenses,
          totalSalaries,
          netProfit,
        },
        salesByMethod: {
          cash: cashSales,
          bank: bankSales,
          credit: creditSales,
        },
        details: {
          invoices: allInvoices,
          purchases: allPurchases,
          expenses: allExpenses,
          salaries: allSalaries,
        },
      };
    }),
});
