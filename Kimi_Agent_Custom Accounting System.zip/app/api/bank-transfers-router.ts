import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { bankTransfers } from "@db/schema";
import { eq, desc, gte, lte, and } from "drizzle-orm";

export const bankTransfersRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(bankTransfers).orderBy(desc(bankTransfers.createdAt));
  }),

  create: publicQuery
    .input(
      z.object({
        type: z.enum(["deposit", "withdraw"]),
        amount: z.number(),
        fee: z.number().optional(),
        netAmount: z.number(),
        description: z.string().optional(),
        date: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(bankTransfers).values({ ...input, createdBy: 1 });
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        type: z.enum(["deposit", "withdraw"]).optional(),
        amount: z.number().optional(),
        fee: z.number().optional(),
        netAmount: z.number().optional(),
        description: z.string().optional(),
        date: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(bankTransfers).set(data).where(eq(bankTransfers.id, id));
      return { success: true };
    }),

  delete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(bankTransfers).where(eq(bankTransfers.id, input.id));
    return { success: true };
  }),

  filter: publicQuery
    .input(z.object({ fromDate: z.string().optional(), toDate: z.string().optional(), type: z.string().optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.fromDate) conditions.push(gte(bankTransfers.date, input.fromDate));
      if (input.toDate) conditions.push(lte(bankTransfers.date, input.toDate));
      if (input.type) conditions.push(eq(bankTransfers.type, input.type as "deposit" | "withdraw"));

      if (conditions.length > 0) {
        return db.select().from(bankTransfers).where(and(...conditions)).orderBy(desc(bankTransfers.createdAt));
      }
      return db.select().from(bankTransfers).orderBy(desc(bankTransfers.createdAt));
    }),
});
