import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "@db/connection";
import { saleTypes } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const saleTypesRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(saleTypes).orderBy(desc(saleTypes.createdAt));
  }),

  active: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(saleTypes).where(eq(saleTypes.isActive, true)).orderBy(saleTypes.name);
  }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        defaultDiscount: z.number().min(0).max(100).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(saleTypes).values(input);
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        defaultDiscount: z.number().min(0).max(100).optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(saleTypes).set(data).where(eq(saleTypes.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(saleTypes).where(eq(saleTypes.id, input.id));
      return { success: true };
    }),
});
