import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import type { User } from "@db/schema";
import { authenticateRequest } from "./kimi/auth";
import { verifyToken } from "./local-auth-router";
import { getDb } from "@db/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: User;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };

  // Try Kimi OAuth first
  try {
    ctx.user = await authenticateRequest(opts.req.headers);
  } catch {
    // OAuth failed, try local auth
  }

  // Try local auth if OAuth didn't work
  if (!ctx.user) {
    try {
      const authHeader = opts.req.headers.get("x-auth-token");
      if (authHeader) {
        const payload = await verifyToken(authHeader);
        if (payload) {
          const db = getDb();
          const [localUser] = await db
            .select()
            .from(users)
            .where(eq(users.id, payload.userId))
            .limit(1);
          if (localUser) {
            ctx.user = localUser;
          }
        }
      }
    } catch {
      // Local auth also failed
    }
  }

  return ctx;
}
