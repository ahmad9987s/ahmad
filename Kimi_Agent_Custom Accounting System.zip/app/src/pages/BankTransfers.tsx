import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Plus, Trash2, Loader2, X, ArrowDownLeft, ArrowUpRight, Landmark } from "lucide-react";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

export default function BankTransfers() {
  const utils = trpc.useUtils();
  const { data: transfers, isLoading } = trpc.bankTransfers.list.useQuery();
  const [showCreate, setShowCreate] = useState(false);

  const [type, setType] = useState<"deposit" | "withdraw">("deposit");
  const [amount, setAmount] = useState(0);
  const [fee, setFee] = useState(0);
  const [description, setDescription] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);

  const createTransfer = trpc.bankTransfers.create.useMutation({
    onSuccess: () => { utils.bankTransfers.list.invalidate(); utils.dashboard.stats.invalidate(); resetForm(); setShowCreate(false); },
  });

  const deleteTransfer = trpc.bankTransfers.delete.useMutation({
    onSuccess: () => { utils.bankTransfers.list.invalidate(); },
  });

  function resetForm() {
    setType("deposit"); setAmount(0); setFee(0); setDescription(""); setDate(new Date().toISOString().split("T")[0]);
  }

  const netAmount = amount - fee;
  const totalDeposits = transfers?.filter((t) => t.type === "deposit").reduce((sum, t) => sum + Number(t.netAmount), 0) || 0;
  const totalWithdraws = transfers?.filter((t) => t.type === "withdraw").reduce((sum, t) => sum + Number(t.netAmount), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">التحويلات البنكية</h1>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> تحويل جديد
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="stat-card">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
              <ArrowDownLeft className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">إجمالي الإيداعات</p>
              <p className="text-lg font-bold text-emerald-600">{formatCurrency(totalDeposits)}</p>
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <ArrowUpRight className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">إجمالي السحوبات</p>
              <p className="text-lg font-bold text-red-600">{formatCurrency(totalWithdraws)}</p>
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Landmark className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">الرصيد</p>
              <p className="text-lg font-bold text-blue-600">{formatCurrency(totalDeposits - totalWithdraws)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-48"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">التاريخ</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">النوع</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">المبلغ</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الرسوم</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الصافي</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الوصف</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-slate-600">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {transfers && transfers.length > 0 ? (
                  transfers.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm text-slate-600">{t.date}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${t.type === "deposit" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>
                          {t.type === "deposit" ? "إيداع" : "سحب"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm font-medium">{formatCurrency(Number(t.amount))}</td>
                      <td className="px-4 py-3 text-sm text-red-500">{formatCurrency(Number(t.fee))}</td>
                      <td className="px-4 py-3 text-sm font-bold">{formatCurrency(Number(t.netAmount))}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{t.description || "-"}</td>
                      <td className="px-4 py-3 text-center">
                        <button onClick={() => { if (confirm("هل أنت متأكد؟")) deleteTransfer.mutate({ id: t.id }); }} className="p-1.5 hover:bg-red-100 rounded-lg text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-400">لا توجد تحويلات</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">تحويل جديد</h2>
              <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex gap-4">
                <button onClick={() => setType("deposit")} className={`flex-1 py-3 rounded-xl font-medium transition-colors ${type === "deposit" ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-600"}`}>
                  <ArrowDownLeft className="w-5 h-5 inline-block ml-2" />إيداع
                </button>
                <button onClick={() => setType("withdraw")} className={`flex-1 py-3 rounded-xl font-medium transition-colors ${type === "withdraw" ? "bg-red-600 text-white" : "bg-slate-100 text-slate-600"}`}>
                  <ArrowUpRight className="w-5 h-5 inline-block ml-2" />سحب
                </button>
              </div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">المبلغ *</label><input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} className="input-field" min="0" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">رسوم التحويل (1%)</label>
                <div className="flex gap-2">
                  <input type="number" value={fee} onChange={(e) => setFee(Number(e.target.value))} className="input-field" min="0" />
                  <button onClick={() => setFee(Math.round(amount * 0.01))} className="px-4 py-2 bg-slate-100 rounded-lg text-sm hover:bg-slate-200">احسب 1%</button>
                </div>
              </div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الصافي</label><div className="px-3 py-2 bg-slate-100 rounded-lg text-sm font-bold">{formatCurrency(netAmount)}</div></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">التاريخ</label><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input-field" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الوصف</label><textarea value={description} onChange={(e) => setDescription(e.target.value)} className="input-field" rows={2} placeholder="اختياري" dir="rtl" /></div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowCreate(false)} className="btn-secondary">إلغاء</button>
              <button onClick={() => {
                if (amount <= 0) { alert("الرجاء إدخال مبلغ صحيح"); return; }
                createTransfer.mutate({ type, amount, fee, netAmount, description: description || undefined, date });
              }} disabled={createTransfer.isPending} className="btn-primary">
                {createTransfer.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
