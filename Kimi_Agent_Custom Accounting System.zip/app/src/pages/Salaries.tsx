import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Plus, Trash2, Loader2, X, CreditCard } from "lucide-react";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

const MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];

export default function Salaries() {
  const utils = trpc.useUtils();
  const { data: salaries, isLoading } = trpc.salaries.list.useQuery();
  const [showCreate, setShowCreate] = useState(false);

  const [employeeName, setEmployeeName] = useState("");
  const [amount, setAmount] = useState(0);
  const [month, setMonth] = useState(MONTHS[new Date().getMonth()]);
  const [year, setYear] = useState(new Date().getFullYear());
  const [description, setDescription] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);

  const createSalary = trpc.salaries.create.useMutation({
    onSuccess: () => { utils.salaries.list.invalidate(); utils.dashboard.stats.invalidate(); resetForm(); setShowCreate(false); },
  });

  const deleteSalary = trpc.salaries.delete.useMutation({
    onSuccess: () => { utils.salaries.list.invalidate(); utils.dashboard.stats.invalidate(); },
  });

  function resetForm() {
    setEmployeeName(""); setAmount(0); setMonth(MONTHS[new Date().getMonth()]); setYear(new Date().getFullYear()); setDescription(""); setDate(new Date().toISOString().split("T")[0]);
  }

  const totalSalaries = salaries?.reduce((sum, s) => sum + Number(s.amount), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">الرواتب</h1>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> راتب جديد
        </button>
      </div>

      <div className="stat-card">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
            <CreditCard className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <p className="text-sm text-slate-500">إجمالي الرواتب</p>
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(totalSalaries)}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-48"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الموظف</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الشهر</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">المبلغ</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">التاريخ</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-slate-600">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {salaries && salaries.length > 0 ? (
                  salaries.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-slate-900">{s.employeeName}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{s.month} {s.year}</td>
                      <td className="px-4 py-3 text-sm font-bold text-purple-600">{formatCurrency(Number(s.amount))}</td>
                      <td className="px-4 py-3 text-sm text-slate-500">{s.date}</td>
                      <td className="px-4 py-3 text-center">
                        <button onClick={() => { if (confirm("هل أنت متأكد؟")) deleteSalary.mutate({ id: s.id }); }} className="p-1.5 hover:bg-red-100 rounded-lg text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">لا توجد رواتب</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">راتب جديد</h2>
              <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div><label className="block text-sm font-medium text-slate-700 mb-1">اسم الموظف *</label><input type="text" value={employeeName} onChange={(e) => setEmployeeName(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">المبلغ *</label><input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} className="input-field" min="0" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-slate-700 mb-1">الشهر</label>
                  <select value={month} onChange={(e) => setMonth(e.target.value)} className="input-field">
                    {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-medium text-slate-700 mb-1">السنة</label><input type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} className="input-field" /></div>
              </div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">التاريخ</label><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input-field" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الوصف</label><textarea value={description} onChange={(e) => setDescription(e.target.value)} className="input-field" rows={2} placeholder="اختياري" dir="rtl" /></div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowCreate(false)} className="btn-secondary">إلغاء</button>
              <button onClick={() => {
                if (!employeeName.trim() || amount <= 0) { alert("الرجاء ملء جميع الحقول المطلوبة"); return; }
                createSalary.mutate({ employeeName, amount, month, year, description: description || undefined, date });
              }} disabled={createSalary.isPending} className="btn-primary">
                {createSalary.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
