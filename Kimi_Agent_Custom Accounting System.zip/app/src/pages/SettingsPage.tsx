import { useState, useEffect } from "react";
import { trpc } from "@/providers/trpc";
import { Settings, Store, Save, Loader2, Tag, Percent } from "lucide-react";

export default function SettingsPage() {
  const utils = trpc.useUtils();
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const { data: saleTypes, isLoading: typesLoading } = trpc.saleTypes.list.useQuery();

  const [shopName, setShopName] = useState("ABDO");
  const [shopAddress, setShopAddress] = useState("أريحا - وسط البلد - شارع البنوك");
  const [shopPhone1, setShopPhone1] = useState("");
  const [shopPhone2, setShopPhone2] = useState("");
  const [defaultDiscount, setDefaultDiscount] = useState(0);
  const [currency, setCurrency] = useState("₪");
  const [taxRate, setTaxRate] = useState(0);
  const [invoicePrefix, setInvoicePrefix] = useState("INV");

  const [showAddType, setShowAddType] = useState(false);
  const [newTypeName, setNewTypeName] = useState("");
  const [newTypeDesc, setNewTypeDesc] = useState("");
  const [newTypeDiscount, setNewTypeDiscount] = useState(0);

  useEffect(() => {
    if (settings) {
      setShopName(settings.shopName);
      setShopAddress(settings.shopAddress || "أريحا - وسط البلد - شارع البنوك");
      setShopPhone1(settings.shopPhone1 || "");
      setShopPhone2(settings.shopPhone2 || "");
      setDefaultDiscount(Number(settings.defaultDiscount));
      setCurrency(settings.currency || "₪");
      setTaxRate(Number(settings.taxRate));
      setInvoicePrefix(settings.invoicePrefix || "INV");
    }
  }, [settings]);

  const updateSettings = trpc.settings.upsert.useMutation({
    onSuccess: () => { utils.settings.get.invalidate(); },
  });

  const createSaleType = trpc.saleTypes.create.useMutation({
    onSuccess: () => { utils.saleTypes.list.invalidate(); setShowAddType(false); setNewTypeName(""); setNewTypeDesc(""); setNewTypeDiscount(0); },
  });

  const updateSaleType = trpc.saleTypes.update.useMutation({
    onSuccess: () => { utils.saleTypes.list.invalidate(); },
  });

  const deleteSaleType = trpc.saleTypes.delete.useMutation({
    onSuccess: () => { utils.saleTypes.list.invalidate(); },
  });

  if (isLoading) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">الإعدادات</h1>
      </div>

      {/* Shop Settings */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
        <div className="flex items-center gap-2 mb-6">
          <Store className="w-5 h-5 text-teal-600" />
          <h2 className="text-lg font-bold text-slate-900">إعدادات المحل</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">اسم المحل *</label>
            <input type="text" value={shopName} onChange={(e) => setShopName(e.target.value)} className="input-field" dir="rtl" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">العملة</label>
            <input type="text" value={currency} onChange={(e) => setCurrency(e.target.value)} className="input-field" />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-1">العنوان</label>
            <input type="text" value={shopAddress} onChange={(e) => setShopAddress(e.target.value)} className="input-field" dir="rtl" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">هاتف 1</label>
            <input type="text" value={shopPhone1} onChange={(e) => setShopPhone1(e.target.value)} className="input-field" dir="rtl" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">هاتف 2</label>
            <input type="text" value={shopPhone2} onChange={(e) => setShopPhone2(e.target.value)} className="input-field" dir="rtl" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">نسبة الخصم الافتراضية %</label>
            <input type="number" value={defaultDiscount} onChange={(e) => setDefaultDiscount(Number(e.target.value))} className="input-field" min="0" max="100" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">نسبة الضريبة %</label>
            <input type="number" value={taxRate} onChange={(e) => setTaxRate(Number(e.target.value))} className="input-field" min="0" max="100" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">بادئة رقم الفاتورة</label>
            <input type="text" value={invoicePrefix} onChange={(e) => setInvoicePrefix(e.target.value)} className="input-field" />
          </div>
        </div>
        <div className="mt-6">
          <button
            onClick={() => updateSettings.mutate({ shopName, shopAddress, shopPhone1: shopPhone1 || undefined, shopPhone2: shopPhone2 || undefined, defaultDiscount, currency, taxRate, invoicePrefix })}
            disabled={updateSettings.isPending}
            className="btn-primary flex items-center gap-2"
          >
            {updateSettings.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            حفظ الإعدادات
          </button>
        </div>
      </div>

      {/* Sale Types */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-teal-600" />
            <h2 className="text-lg font-bold text-slate-900">أنواع المبيعات</h2>
          </div>
          <button onClick={() => setShowAddType(true)} className="text-sm text-teal-600 hover:text-teal-700 font-medium">+ نوع جديد</button>
        </div>

        {showAddType && (
          <div className="bg-slate-50 rounded-xl p-4 mb-4 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الاسم *</label><input type="text" value={newTypeName} onChange={(e) => setNewTypeName(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الوصف</label><input type="text" value={newTypeDesc} onChange={(e) => setNewTypeDesc(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">خصم افتراضي %</label><input type="number" value={newTypeDiscount} onChange={(e) => setNewTypeDiscount(Number(e.target.value))} className="input-field" min="0" max="100" /></div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => { if (!newTypeName.trim()) return; createSaleType.mutate({ name: newTypeName, description: newTypeDesc || undefined, defaultDiscount: newTypeDiscount }); }} disabled={createSaleType.isPending} className="btn-primary text-sm">
                {createSaleType.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : "حفظ"}
              </button>
              <button onClick={() => setShowAddType(false)} className="btn-secondary text-sm">إلغاء</button>
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50"><tr><th className="px-3 py-2 text-right font-semibold">الاسم</th><th className="px-3 py-2 text-right font-semibold">الوصف</th><th className="px-3 py-2 text-right font-semibold">الخصم %</th><th className="px-3 py-2 text-center font-semibold">الحالة</th><th className="px-3 py-2 text-center font-semibold">إجراءات</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {saleTypes?.map((st) => (
                <tr key={st.id} className="hover:bg-slate-50">
                  <td className="px-3 py-2 font-medium">{st.name}</td>
                  <td className="px-3 py-2 text-slate-500">{st.description || "-"}</td>
                  <td className="px-3 py-2">{Number(st.defaultDiscount) > 0 ? `${st.defaultDiscount}%` : "-"}</td>
                  <td className="px-3 py-2 text-center">
                    <button onClick={() => updateSaleType.mutate({ id: st.id, isActive: !st.isActive })} className={`px-2 py-0.5 rounded-full text-xs ${st.isActive ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                      {st.isActive ? "نشط" : "معطل"}
                    </button>
                  </td>
                  <td className="px-3 py-2 text-center">
                    <button onClick={() => { if (confirm("هل أنت متأكد؟")) deleteSaleType.mutate({ id: st.id }); }} className="p-1 hover:bg-red-100 rounded text-red-500">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </td>
                </tr>
              ))}
              {(!saleTypes || saleTypes.length === 0) && <tr><td colSpan={5} className="px-3 py-4 text-center text-slate-400">لا توجد أنواع مبيعات</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
