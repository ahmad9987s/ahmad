import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Plus, Trash2, Loader2, X, UserCircle, Shield } from "lucide-react";

export default function Users() {
  const utils = trpc.useUtils();
  const { data: users, isLoading } = trpc.users.list.useQuery();
  const [showCreate, setShowCreate] = useState(false);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState<"admin" | "manager" | "cashier">("cashier");

  const createUser = trpc.users.create.useMutation({
    onSuccess: () => { utils.users.list.invalidate(); resetForm(); setShowCreate(false); },
  });

  const deleteUser = trpc.users.delete.useMutation({
    onSuccess: () => { utils.users.list.invalidate(); },
  });

  function resetForm() {
    setUsername(""); setPassword(""); setDisplayName(""); setRole("cashier");
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">إدارة المستخدمين</h1>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> مستخدم جديد
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-48"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الاسم</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">اسم المستخدم</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الصلاحية</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الحالة</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-slate-600">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users && users.length > 0 ? (
                  users.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-slate-900 flex items-center gap-2">
                        <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center">
                          <UserCircle className="w-4 h-4 text-teal-600" />
                        </div>
                        {u.displayName}
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{u.username}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                          u.role === "admin" ? "bg-red-100 text-red-700" :
                          u.role === "manager" ? "bg-blue-100 text-blue-700" :
                          "bg-slate-100 text-slate-600"
                        }`}>
                          {u.role === "admin" ? "مدير" : u.role === "manager" ? "مدير" : "كاشير"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs ${u.isActive ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                          {u.isActive ? "نشط" : "معطل"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button onClick={() => { if (confirm("هل أنت متأكد من حذف هذا المستخدم؟")) deleteUser.mutate({ id: u.id }); }} className="p-1.5 hover:bg-red-100 rounded-lg text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">لا يوجد مستخدمين</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-md my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">مستخدم جديد</h2>
              <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الاسم المعروض *</label><input type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">اسم المستخدم *</label><input type="text" value={username} onChange={(e) => setUsername(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">كلمة المرور *</label><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="input-field" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الصلاحية</label>
                <select value={role} onChange={(e) => setRole(e.target.value as "admin" | "manager" | "cashier")} className="input-field">
                  <option value="admin">مدير (Admin)</option>
                  <option value="manager">مدير (Manager)</option>
                  <option value="cashier">كاشير</option>
                </select>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowCreate(false)} className="btn-secondary">إلغاء</button>
              <button onClick={() => {
                if (!username.trim() || !password.trim() || !displayName.trim()) { alert("الرجاء ملء جميع الحقول المطلوبة"); return; }
                createUser.mutate({ username, password, displayName, role });
              }} disabled={createUser.isPending} className="btn-primary">
                {createUser.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
