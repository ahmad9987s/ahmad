import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Plus, Search, Trash2, Edit2, Loader2, X, ShoppingCart } from "lucide-react";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

export default function Purchases() {
  const utils = trpc.useUtils();
  const { data: purchases, isLoading } = trpc.purchases.list.useQuery();
  const { data: suppliers } = trpc.suppliers.list.useQuery();
  const { data: products } = trpc.products.active.useQuery();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [showSuppliers, setShowSuppliers] = useState(false);
  const [showAddSupplier, setShowAddSupplier] = useState(false);

  // Purchase form
  const [supplierId, setSupplierId] = useState<number | undefined>();
  const [productId, setProductId] = useState<number | undefined>();
  const [productName, setProductName] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [unitPrice, setUnitPrice] = useState(0);
  const [paid, setPaid] = useState(0);
  const [notes, setNotes] = useState("");

  // Supplier form
  const [supName, setSupName] = useState("");
  const [supPhone, setSupPhone] = useState("");
  const [supAddress, setSupAddress] = useState("");

  const createPurchase = trpc.purchases.create.useMutation({
    onSuccess: () => {
      utils.purchases.list.invalidate();
      utils.dashboard.stats.invalidate();
      resetForm();
      setShowCreate(false);
    },
  });

  const createSupplier = trpc.suppliers.create.useMutation({
    onSuccess: () => {
      utils.suppliers.list.invalidate();
      setShowAddSupplier(false);
      setSupName(""); setSupPhone(""); setSupAddress("");
    },
  });

  function resetForm() {
    setSupplierId(undefined);
    setProductId(undefined);
    setProductName("");
    setQuantity(1);
    setUnitPrice(0);
    setPaid(0);
    setNotes("");
  }

  function handleSubmit() {
    if (!productName.trim()) { alert("الرجاء إدخال اسم المنتج"); return; }
    const total = quantity * unitPrice;
    createPurchase.mutate({ supplierId, productId, productName, quantity, unitPrice, total, paid, notes: notes || undefined });
  }

  const filtered = purchases?.filter((p) =>
    (p.productName || "").includes(search) ||
    String(p.total).includes(search)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">المشتريات</h1>
        <div className="flex gap-2">
          <button onClick={() => setShowSuppliers(true)} className="btn-secondary flex items-center gap-2">
            <ShoppingCart className="w-4 h-4" /> التجار
          </button>
          <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" /> مشتريات جديدة
          </button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input type="text" placeholder="بحث..." value={search} onChange={(e) => setSearch(e.target.value)} className="input-field pr-10" dir="rtl" />
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-48"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">المنتج</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الكمية</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">سعر الوحدة</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">المجموع</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">مدفوع</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">التاريخ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered && filtered.length > 0 ? (
                  filtered.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-slate-900">{p.productName || "-"}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{p.quantity}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatCurrency(Number(p.unitPrice))}</td>
                      <td className="px-4 py-3 text-sm font-bold text-slate-900">{formatCurrency(Number(p.total))}</td>
                      <td className="px-4 py-3 text-sm text-emerald-600">{formatCurrency(Number(p.paid))}</td>
                      <td className="px-4 py-3 text-sm text-slate-500">{new Date(p.createdAt).toLocaleDateString("ar-SA")}</td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">لا توجد مشتريات</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">مشتريات جديدة</h2>
              <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">التاجر</label>
                <select value={supplierId || ""} onChange={(e) => setSupplierId(e.target.value ? Number(e.target.value) : undefined)} className="input-field">
                  <option value="">اختياري</option>
                  {suppliers?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">الصنف المخزوني (اختياري)</label>
                <select value={productId || ""} onChange={(e) => {
                  const pid = e.target.value ? Number(e.target.value) : undefined;
                  setProductId(pid);
                  const prod = products?.find((p) => p.id === pid);
                  if (prod) setProductName(prod.name);
                }} className="input-field">
                  <option value="">بدون ربط</option>
                  {products?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">اسم المنتج *</label>
                <input type="text" value={productName} onChange={(e) => setProductName(e.target.value)} className="input-field" placeholder="اسم المنتج" dir="rtl" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">الكمية</label>
                  <input type="number" value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} className="input-field" min="1" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">سعر الوحدة</label>
                  <input type="number" value={unitPrice} onChange={(e) => setUnitPrice(Number(e.target.value))} className="input-field" min="0" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">مدفوع</label>
                  <input type="number" value={paid} onChange={(e) => setPaid(Number(e.target.value))} className="input-field" min="0" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المجموع</label>
                  <div className="px-3 py-2 bg-slate-100 rounded-lg text-sm font-bold">{formatCurrency(quantity * unitPrice)}</div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ملاحظات</label>
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="input-field" rows={2} placeholder="اختياري" dir="rtl" />
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowCreate(false)} className="btn-secondary">إلغاء</button>
              <button onClick={handleSubmit} disabled={createPurchase.isPending} className="btn-primary flex items-center gap-2">
                {createPurchase.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                حفظ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Suppliers Modal */}
      {showSuppliers && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">سجل التجار</h2>
              <div className="flex gap-2">
                <button onClick={() => setShowAddSupplier(true)} className="text-sm text-teal-600 hover:text-teal-700 font-medium">+ تاجر جديد</button>
                <button onClick={() => setShowSuppliers(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
              </div>
            </div>
            <div className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50"><tr><th className="px-3 py-2 text-right font-semibold">الاسم</th><th className="px-3 py-2 text-right font-semibold">الهاتف</th><th className="px-3 py-2 text-right font-semibold">الرصيد</th></tr></thead>
                  <tbody className="divide-y divide-slate-100">
                    {suppliers?.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50"><td className="px-3 py-2 font-medium">{s.name}</td><td className="px-3 py-2 text-slate-500">{s.phone || "-"}</td><td className="px-3 py-2">{formatCurrency(Number(s.balance))}</td></tr>
                    ))}
                    {(!suppliers || suppliers.length === 0) && <tr><td colSpan={3} className="px-3 py-4 text-center text-slate-400">لا يوجد تجار</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Supplier Modal */}
      {showAddSupplier && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-md my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900">تاجر جديد</h2>
              <button onClick={() => setShowAddSupplier(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الاسم *</label><input type="text" value={supName} onChange={(e) => setSupName(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الهاتف</label><input type="text" value={supPhone} onChange={(e) => setSupPhone(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">العنوان</label><input type="text" value={supAddress} onChange={(e) => setSupAddress(e.target.value)} className="input-field" dir="rtl" /></div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowAddSupplier(false)} className="btn-secondary">إلغاء</button>
              <button onClick={() => { if (!supName.trim()) return; createSupplier.mutate({ name: supName, phone: supPhone || undefined, address: supAddress || undefined }); }} disabled={createSupplier.isPending} className="btn-primary">
                {createSupplier.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
