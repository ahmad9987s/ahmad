import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { TrendingUp, Loader2, Receipt, ShoppingCart, Wallet, CreditCard } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

const COLORS = ["#10b981", "#f59e0b", "#ef4444", "#8b5cf6"];

export default function Profit() {
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const { data: report, isLoading } = trpc.profit.report.useQuery(
    { fromDate: fromDate || undefined, toDate: toDate || undefined },
    { refetchInterval: 5000 }
  );

  const expenseData = report ? [
    { name: "المشتريات", value: report.summary.totalPurchases },
    { name: "المصاريف", value: report.summary.totalExpenses },
    { name: "الرواتب", value: report.summary.totalSalaries },
  ].filter((d) => d.value > 0) : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">تقرير الأرباح</h1>
      </div>

      {/* Date Filter */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
        <div className="flex flex-col sm:flex-row gap-4 items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-700 mb-1">من تاريخ</label>
            <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="input-field" />
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-700 mb-1">إلى تاريخ</label>
            <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="input-field" />
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-48"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
      ) : report ? (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="stat-card">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <Receipt className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">المبيعات</p>
                  <p className="text-xl font-bold text-emerald-600">{formatCurrency(report.summary.totalSales)}</p>
                </div>
              </div>
            </div>
            <div className="stat-card">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                  <ShoppingCart className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">المشتريات</p>
                  <p className="text-xl font-bold text-amber-600">{formatCurrency(report.summary.totalPurchases)}</p>
                </div>
              </div>
            </div>
            <div className="stat-card">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">المصاريف</p>
                  <p className="text-xl font-bold text-red-600">{formatCurrency(report.summary.totalExpenses)}</p>
                </div>
              </div>
            </div>
            <div className="stat-card">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">الرواتب</p>
                  <p className="text-xl font-bold text-purple-600">{formatCurrency(report.summary.totalSalaries)}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Net Profit & Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <h2 className="text-lg font-bold text-slate-900 mb-4">صافي الربح</h2>
              <div className="text-center py-8">
                <div className={`text-5xl font-bold mb-2 ${report.summary.netProfit >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                  {formatCurrency(report.summary.netProfit)}
                </div>
                <p className={`text-lg ${report.summary.netProfit >= 0 ? "text-emerald-500" : "text-red-500"}`}>
                  {report.summary.netProfit >= 0 ? "ربح" : "خسارة"}
                </p>
              </div>
              <div className="space-y-3 border-t pt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">إجمالي الإيرادات:</span>
                  <span className="font-medium">{formatCurrency(report.summary.totalSales)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">إجمالي التكاليف:</span>
                  <span className="font-medium text-red-600">{formatCurrency(report.summary.totalPurchases + report.summary.totalExpenses + report.summary.totalSalaries)}</span>
                </div>
                {report.summary.totalDiscounts > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">إجمالي الخصومات:</span>
                    <span className="font-medium text-amber-600">{formatCurrency(report.summary.totalDiscounts)}</span>
                  </div>
                )}
                <div className="border-t pt-3 flex justify-between text-lg font-bold">
                  <span>نسبة الربح:</span>
                  <span className={report.summary.totalSales > 0 ? (report.summary.netProfit / report.summary.totalSales * 100 >= 0 ? "text-emerald-600" : "text-red-600") : "text-slate-400"}>
                    {report.summary.totalSales > 0 ? `${(report.summary.netProfit / report.summary.totalSales * 100).toFixed(1)}%` : "N/A"}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <h2 className="text-lg font-bold text-slate-900 mb-4">توزيع التكاليف</h2>
              {expenseData.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie
                      data={expenseData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {expenseData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-slate-400">لا توجد بيانات</div>
              )}
            </div>
          </div>

          {/* Sales by Method */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
            <h2 className="text-lg font-bold text-slate-900 mb-4">المبيعات حسب طريقة الدفع</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-emerald-50 rounded-xl p-4 text-center">
                <p className="text-sm text-emerald-600 mb-1">كاش</p>
                <p className="text-2xl font-bold text-emerald-700">{formatCurrency(report.salesByMethod.cash)}</p>
              </div>
              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <p className="text-sm text-blue-600 mb-1">بنكي</p>
                <p className="text-2xl font-bold text-blue-700">{formatCurrency(report.salesByMethod.bank)}</p>
              </div>
              <div className="bg-orange-50 rounded-xl p-4 text-center">
                <p className="text-sm text-orange-600 mb-1">آجل</p>
                <p className="text-2xl font-bold text-orange-700">{formatCurrency(report.salesByMethod.credit)}</p>
              </div>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
