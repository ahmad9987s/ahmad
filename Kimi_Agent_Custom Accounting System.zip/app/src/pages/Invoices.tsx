import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useNavigate } from "react-router";
import {
  Plus, Search, Printer, Trash2, Edit2, Eye, Loader2, X, Receipt, ArrowRight,
} from "lucide-react";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

export default function Invoices() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const { data: invoices, isLoading } = trpc.invoices.list.useQuery();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [showEdit, setShowEdit] = useState<number | null>(null);
  const [showView, setShowView] = useState<number | null>(null);
  const [showPrint, setShowPrint] = useState<number | null>(null);

  // Form state
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "bank" | "credit">("cash");
  const [saleTypeId, setSaleTypeId] = useState<number | undefined>();
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<Array<{
    productName: string; quantity: number; unitPrice: number; discount: number; total: number;
  }>>([{ productName: "", quantity: 1, unitPrice: 0, discount: 0, total: 0 }]);

  const { data: saleTypes } = trpc.saleTypes.active.useQuery();
  const { data: settings } = trpc.settings.get.useQuery();

  const createInvoice = trpc.invoices.create.useMutation({
    onSuccess: () => {
      utils.invoices.list.invalidate();
      utils.dashboard.stats.invalidate();
      resetForm();
      setShowCreate(false);
    },
  });

  const updateInvoice = trpc.invoices.update.useMutation({
    onSuccess: () => {
      utils.invoices.list.invalidate();
      setShowEdit(null);
    },
  });

  const deleteInvoice = trpc.invoices.delete.useMutation({
    onSuccess: () => {
      utils.invoices.list.invalidate();
      utils.dashboard.stats.invalidate();
    },
  });

  const { data: viewInvoice } = trpc.invoices.getById.useQuery(
    { id: showView! },
    { enabled: !!showView }
  );

  const { data: editInvoice } = trpc.invoices.getById.useQuery(
    { id: showEdit! },
    { enabled: !!showEdit }
  );

  const { data: printInvoice } = trpc.invoices.getById.useQuery(
    { id: showPrint! },
    { enabled: !!showPrint }
  );

  function resetForm() {
    setCustomerName("");
    setCustomerPhone("");
    setPaymentMethod("cash");
    setSaleTypeId(undefined);
    setNotes("");
    setItems([{ productName: "", quantity: 1, unitPrice: 0, discount: 0, total: 0 }]);
  }

  function addItem() {
    setItems([...items, { productName: "", quantity: 1, unitPrice: 0, discount: 0, total: 0 }]);
  }

  function updateItem(index: number, field: string, value: string | number) {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    if (field === "quantity" || field === "unitPrice" || field === "discount") {
      const q = Number(newItems[index].quantity);
      const p = Number(newItems[index].unitPrice);
      const d = Number(newItems[index].discount);
      newItems[index].total = q * p - d;
    }
    setItems(newItems);
  }

  function removeItem(index: number) {
    if (items.length === 1) return;
    setItems(items.filter((_, i) => i !== index));
  }

  function getTotals() {
    const subtotal = items.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitPrice), 0);
    const discount = items.reduce((sum, item) => sum + Number(item.discount), 0);
    const selectedSaleType = saleTypes?.find((st) => st.id === saleTypeId);
    const typeDiscount = selectedSaleType ? (subtotal * Number(selectedSaleType.defaultDiscount)) / 100 : 0;
    const totalDiscount = discount + typeDiscount;
    const tax = ((subtotal - totalDiscount) * Number(settings?.taxRate || 0)) / 100;
    const total = subtotal - totalDiscount + tax;
    return { subtotal, discount: totalDiscount, tax, total };
  }

  function handleSubmit() {
    const { subtotal, discount, tax, total } = getTotals();
    if (items.some((i) => !i.productName || i.quantity <= 0)) {
      alert("الرجاء ملء جميع بيانات الأصناف");
      return;
    }
    createInvoice.mutate({
      customerName: customerName || undefined,
      customerPhone: customerPhone || undefined,
      saleTypeId,
      paymentMethod,
      subtotal,
      discount,
      tax,
      total,
      notes: notes || undefined,
      items: items.map((i) => ({
        productName: i.productName,
        quantity: Number(i.quantity),
        unitPrice: Number(i.unitPrice),
        discount: Number(i.discount),
        total: Number(i.total),
      })),
    });
  }

  function handlePrint() {
    window.print();
  }

  const filteredInvoices = invoices?.filter((inv) =>
    inv.invoiceNumber.toLowerCase().includes(search.toLowerCase()) ||
    (inv.customerName || "").includes(search)
  );

  return (
    <div className="space-y-6 no-print">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">الفواتير</h1>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          فاتورة جديدة
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="بحث برقم الفاتورة أو اسم العميل..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="input-field pr-10"
          dir="rtl"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-48">
            <Loader2 className="w-6 h-6 animate-spin text-teal-600" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الفاتورة</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">العميل</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الدفع</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الخصم</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">المجموع</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">التاريخ</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-slate-600">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInvoices && filteredInvoices.length > 0 ? (
                  filteredInvoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-teal-700">{inv.invoiceNumber}</td>
                      <td className="px-4 py-3 text-sm text-slate-700">{inv.customerName || "-"}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          inv.paymentMethod === "cash" ? "bg-emerald-100 text-emerald-700" :
                          inv.paymentMethod === "bank" ? "bg-blue-100 text-blue-700" :
                          "bg-orange-100 text-orange-700"
                        }`}>
                          {inv.paymentMethod === "cash" ? "كاش" : inv.paymentMethod === "bank" ? "بنكي" : "آجل"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatCurrency(Number(inv.discount))}</td>
                      <td className="px-4 py-3 text-sm font-bold text-slate-900">{formatCurrency(Number(inv.total))}</td>
                      <td className="px-4 py-3 text-sm text-slate-500">{new Date(inv.createdAt).toLocaleDateString("ar-SA")}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => { setShowPrint(inv.id); setTimeout(handlePrint, 100); }} className="p-1.5 hover:bg-slate-100 rounded-lg text-teal-600" title="طباعة">
                            <Printer className="w-4 h-4" />
                          </button>
                          <button onClick={() => setShowView(inv.id)} className="p-1.5 hover:bg-slate-100 rounded-lg text-blue-600" title="عرض">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button onClick={() => setShowEdit(inv.id)} className="p-1.5 hover:bg-slate-100 rounded-lg text-amber-600" title="تعديل">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button onClick={() => { if (confirm("هل أنت متأكد من حذف هذه الفاتورة؟")) deleteInvoice.mutate({ id: inv.id }); }} className="p-1.5 hover:bg-slate-100 rounded-lg text-red-600" title="حذف">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-slate-400">لا توجد فواتير</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-3xl my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">فاتورة جديدة</h2>
              <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              {/* Customer Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">اسم العميل</label>
                  <input type="text" value={customerName} onChange={(e) => setCustomerName(e.target.value)} className="input-field" placeholder="اختياري" dir="rtl" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">هاتف العميل</label>
                  <input type="text" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} className="input-field" placeholder="اختياري" dir="rtl" />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">طريقة الدفع</label>
                  <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value as "cash" | "bank" | "credit")} className="input-field">
                    <option value="cash">كاش</option>
                    <option value="bank">بنكي</option>
                    <option value="credit">آجل</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">نوع البيع</label>
                  <select value={saleTypeId || ""} onChange={(e) => setSaleTypeId(e.target.value ? Number(e.target.value) : undefined)} className="input-field">
                    <option value="">عام</option>
                    {saleTypes?.map((st) => (
                      <option key={st.id} value={st.id}>{st.name} {Number(st.defaultDiscount) > 0 ? `(-${st.defaultDiscount}%)` : ""}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Items */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-slate-700">الأصناف</label>
                  <button onClick={addItem} className="text-sm text-teal-600 hover:text-teal-700 font-medium">+ إضافة صنف</button>
                </div>
                <div className="space-y-2">
                  {items.map((item, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2 items-end">
                      <div className="col-span-4">
                        <input type="text" value={item.productName} onChange={(e) => updateItem(index, "productName", e.target.value)} className="input-field text-sm" placeholder="اسم الصنف" dir="rtl" />
                      </div>
                      <div className="col-span-2">
                        <input type="number" value={item.quantity} onChange={(e) => updateItem(index, "quantity", Number(e.target.value))} className="input-field text-sm" placeholder="الكمية" min="1" />
                      </div>
                      <div className="col-span-2">
                        <input type="number" value={item.unitPrice} onChange={(e) => updateItem(index, "unitPrice", Number(e.target.value))} className="input-field text-sm" placeholder="السعر" min="0" />
                      </div>
                      <div className="col-span-2">
                        <input type="number" value={item.discount} onChange={(e) => updateItem(index, "discount", Number(e.target.value))} className="input-field text-sm" placeholder="الخصم" min="0" />
                      </div>
                      <div className="col-span-1">
                        <span className="text-sm font-medium text-slate-700">{formatCurrency(item.total)}</span>
                      </div>
                      <div className="col-span-1">
                        <button onClick={() => removeItem(index)} className="p-1 hover:bg-red-100 rounded text-red-500">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ملاحظات</label>
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="input-field" rows={2} placeholder="اختياري" dir="rtl" />
              </div>

              {/* Totals */}
              <div className="bg-slate-50 rounded-xl p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">المجموع الفرعي:</span>
                  <span className="font-medium">{formatCurrency(getTotals().subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">الخصم:</span>
                  <span className="font-medium text-red-600">{formatCurrency(getTotals().discount)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">الضريبة:</span>
                  <span className="font-medium">{formatCurrency(getTotals().tax)}</span>
                </div>
                <div className="border-t pt-2 flex justify-between text-lg font-bold">
                  <span>الإجمالي:</span>
                  <span className="text-teal-700">{formatCurrency(getTotals().total)}</span>
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowCreate(false)} className="btn-secondary">إلغاء</button>
              <button onClick={handleSubmit} disabled={createInvoice.isPending} className="btn-primary flex items-center gap-2">
                {createInvoice.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Receipt className="w-4 h-4" />}
                حفظ الفاتورة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Modal */}
      {showView && viewInvoice && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">تفاصيل الفاتورة {viewInvoice.invoiceNumber}</h2>
              <button onClick={() => setShowView(null)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="text-slate-500">العميل:</span> {viewInvoice.customerName || "-"}</div>
                <div><span className="text-slate-500">الدفع:</span> {viewInvoice.paymentMethod === "cash" ? "كاش" : viewInvoice.paymentMethod === "bank" ? "بنكي" : "آجل"}</div>
                <div><span className="text-slate-500">التاريخ:</span> {new Date(viewInvoice.createdAt).toLocaleDateString("ar-SA")}</div>
              </div>
              <table className="w-full text-sm">
                <thead className="bg-slate-50"><tr><th className="px-3 py-2 text-right">الصنف</th><th className="px-3 py-2">الكمية</th><th className="px-3 py-2">السعر</th><th className="px-3 py-2">المجموع</th></tr></thead>
                <tbody className="divide-y divide-slate-100">
                  {viewInvoice.items.map((item) => (
                    <tr key={item.id}><td className="px-3 py-2">{item.productName}</td><td className="px-3 py-2 text-center">{item.quantity}</td><td className="px-3 py-2 text-center">{formatCurrency(Number(item.unitPrice))}</td><td className="px-3 py-2 text-center font-medium">{formatCurrency(Number(item.total))}</td></tr>
                  ))}
                </tbody>
              </table>
              <div className="bg-slate-50 rounded-xl p-4">
                <div className="flex justify-between font-bold text-lg"><span>الإجمالي:</span><span className="text-teal-700">{formatCurrency(Number(viewInvoice.total))}</span></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Print Template */}
      {showPrint && printInvoice && (
        <div className="print-only fixed inset-0 bg-white z-[100]">
          <div className="max-w-md mx-auto p-8">
            <div className="text-center mb-6">
              <h1 className="text-2xl font-bold text-slate-900">{settings?.shopName || "ABDO"}</h1>
              <p className="text-sm text-slate-600 mt-1">{settings?.shopAddress || "أريحا - وسط البلد - شارع البنوك"}</p>
              {settings?.shopPhone1 && <p className="text-sm text-slate-600">{settings.shopPhone1}</p>}
            </div>
            <div className="border-t border-b border-slate-300 py-4 mb-4">
              <div className="flex justify-between text-sm">
                <span>فاتورة: <strong>{printInvoice.invoiceNumber}</strong></span>
                <span>{new Date(printInvoice.createdAt).toLocaleDateString("ar-SA")}</span>
              </div>
              {printInvoice.customerName && <div className="text-sm mt-1">العميل: {printInvoice.customerName}</div>}
            </div>
            <table className="w-full text-sm mb-4">
              <thead><tr className="border-b"><th className="text-right py-2">الصنف</th><th className="text-center py-2">الكمية</th><th className="text-center py-2">السعر</th><th className="text-center py-2">المجموع</th></tr></thead>
              <tbody>
                {printInvoice.items.map((item) => (
                  <tr key={item.id} className="border-b border-slate-100"><td className="py-2">{item.productName}</td><td className="text-center py-2">{item.quantity}</td><td className="text-center py-2">{formatCurrency(Number(item.unitPrice))}</td><td className="text-center py-2 font-medium">{formatCurrency(Number(item.total))}</td></tr>
                ))}
              </tbody>
            </table>
            <div className="border-t pt-4 space-y-1 text-sm">
              <div className="flex justify-between"><span>المجموع:</span><span className="font-bold">{formatCurrency(Number(printInvoice.subtotal))}</span></div>
              {Number(printInvoice.discount) > 0 && <div className="flex justify-between"><span>الخصم:</span><span className="text-red-600">{formatCurrency(Number(printInvoice.discount))}</span></div>}
              {Number(printInvoice.tax) > 0 && <div className="flex justify-between"><span>الضريبة:</span><span>{formatCurrency(Number(printInvoice.tax))}</span></div>}
              <div className="flex justify-between text-lg font-bold pt-2 border-t"><span>الإجمالي:</span><span className="text-teal-700">{formatCurrency(Number(printInvoice.total))}</span></div>
            </div>
            <div className="text-center mt-8 text-sm text-slate-500">
              <p>شكراً لثقتكم بنا</p>
              <p className="mt-1">{settings?.shopPhone1} {settings?.shopPhone2 ? ` - ${settings.shopPhone2}` : ""}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
