import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Plus, Trash2, Loader2, X, Store } from "lucide-react";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

export default function Suppliers() {
  const utils = trpc.useUtils();
  const { data: suppliers, isLoading } = trpc.suppliers.list.useQuery();
  const [showCreate, setShowCreate] = useState(false);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");

  const createSupplier = trpc.suppliers.create.useMutation({
    onSuccess: () => { utils.suppliers.list.invalidate(); resetForm(); setShowCreate(false); },
  });

  const deleteSupplier = trpc.suppliers.delete.useMutation({
    onSuccess: () => { utils.suppliers.list.invalidate(); },
  });

  function resetForm() {
    setName(""); setPhone(""); setEmail(""); setAddress("");
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">التجار</h1>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> تاجر جديد
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-48"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الاسم</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الهاتف</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">العنوان</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الرصيد</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-slate-600">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {suppliers && suppliers.length > 0 ? (
                  suppliers.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-slate-900 flex items-center gap-2">
                        <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
                          <Store className="w-4 h-4 text-amber-600" />
                        </div>
                        {s.name}
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{s.phone || "-"}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{s.address || "-"}</td>
                      <td className={`px-4 py-3 text-sm font-medium ${Number(s.balance) > 0 ? "text-red-600" : "text-emerald-600"}`}>{formatCurrency(Number(s.balance))}</td>
                      <td className="px-4 py-3 text-center">
                        <button onClick={() => { if (confirm("هل أنت متأكد؟")) deleteSupplier.mutate({ id: s.id }); }} className="p-1.5 hover:bg-red-100 rounded-lg text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">لا يوجد تجار</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-md my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">تاجر جديد</h2>
              <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الاسم *</label><input type="text" value={name} onChange={(e) => setName(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الهاتف</label><input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">البريد</label><input type="text" value={email} onChange={(e) => setEmail(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">العنوان</label><input type="text" value={address} onChange={(e) => setAddress(e.target.value)} className="input-field" dir="rtl" /></div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowCreate(false)} className="btn-secondary">إلغاء</button>
              <button onClick={() => { if (!name.trim()) return; createSupplier.mutate({ name, phone: phone || undefined, email: email || undefined, address: address || undefined }); }} disabled={createSupplier.isPending} className="btn-primary">
                {createSupplier.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
