import { trpc } from "@/providers/trpc";
import {
  TrendingUp,
  TrendingDown,
  ShoppingCart,
  Receipt,
  Wallet,
  Banknote,
  Loader2,
  Calendar,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = trpc.dashboard.stats.useQuery();
  const { data: chartData, isLoading: chartLoading } = trpc.dashboard.chartData.useQuery();

  if (statsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-teal-600" />
      </div>
    );
  }

  const today = new Date();
  const dateStr = today.toLocaleDateString("ar-SA", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">لوحة التحكم</h1>
          <p className="text-slate-500 flex items-center gap-1 mt-1">
            <Calendar className="w-4 h-4" />
            {dateStr}
          </p>
        </div>
      </div>

      {/* Today Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="مبيعات اليوم"
          value={stats?.today.sales || 0}
          icon={Receipt}
          iconColor="text-emerald-600"
          iconBg="bg-emerald-100"
          trend="up"
        />
        <StatCard
          title="مشتريات اليوم"
          value={stats?.today.purchases || 0}
          icon={ShoppingCart}
          iconColor="text-amber-600"
          iconBg="bg-amber-100"
          trend="down"
        />
        <StatCard
          title="مصاريف اليوم"
          value={stats?.today.expenses || 0}
          icon={Wallet}
          iconColor="text-red-600"
          iconBg="bg-red-100"
          trend="down"
        />
        <StatCard
          title="صافي اليوم"
          value={stats?.today.net || 0}
          icon={Banknote}
          iconColor={stats?.today.net && stats.today.net >= 0 ? "text-emerald-600" : "text-red-600"}
          iconBg={stats?.today.net && stats.today.net >= 0 ? "bg-emerald-100" : "bg-red-100"}
          trend={stats?.today.net && stats.today.net >= 0 ? "up" : "down"}
        />
      </div>

      {/* Month Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
          <h2 className="text-lg font-bold text-slate-900 mb-4">مخطط المبيعات (آخر 30 يوم)</h2>
          {chartLoading ? (
            <div className="h-64 flex items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-teal-600" />
            </div>
          ) : chartData && chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis
                  dataKey="date"
                  tickFormatter={(val) => val.slice(5)}
                  stroke="#94a3b8"
                  fontSize={12}
                />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip
                  formatter={(value: number) => formatCurrency(value)}
                  labelFormatter={(label) => label}
                />
                <Line
                  type="monotone"
                  dataKey="amount"
                  stroke="#0f766e"
                  strokeWidth={2}
                  dot={{ fill: "#0f766e", r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-64 flex items-center justify-center text-slate-400">
              لا توجد بيانات كافية
            </div>
          )}
        </div>

        {/* Month Summary */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
          <h2 className="text-lg font-bold text-slate-900 mb-4">ملخص الشهر</h2>
          <div className="space-y-4">
            <SummaryRow label="إجمالي المبيعات" value={stats?.month.sales || 0} color="text-emerald-600" />
            <SummaryRow label="إجمالي المشتريات" value={stats?.month.purchases || 0} color="text-amber-600" />
            <SummaryRow label="إجمالي المصاريف" value={stats?.month.expenses || 0} color="text-red-500" />
            <SummaryRow label="إجمالي الرواتب" value={stats?.month.salaries || 0} color="text-purple-500" />
            <div className="border-t pt-3">
              <SummaryRow
                label="صافي الربح"
                value={stats?.month.net || 0}
                color={stats?.month.net && stats.month.net >= 0 ? "text-emerald-700 font-bold" : "text-red-700 font-bold"}
                large
              />
            </div>
            <div className="border-t pt-3">
              <SummaryRow label="الديون المستحقة" value={stats?.pendingDebts || 0} color="text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Invoices */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h2 className="text-lg font-bold text-slate-900">آخر الفواتير</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">رقم الفاتورة</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">العميل</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الدفع</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">المجموع</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">التاريخ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {stats?.recentInvoices && stats.recentInvoices.length > 0 ? (
                stats.recentInvoices.slice(0, 10).map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3 text-sm font-medium text-teal-700">{inv.invoiceNumber}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{inv.customerName || "-"}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        inv.paymentMethod === "cash" ? "bg-emerald-100 text-emerald-700" :
                        inv.paymentMethod === "bank" ? "bg-blue-100 text-blue-700" :
                        "bg-orange-100 text-orange-700"
                      }`}>
                        {inv.paymentMethod === "cash" ? "كاش" : inv.paymentMethod === "bank" ? "بنكي" : "آجل"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm font-medium text-slate-900">{formatCurrency(Number(inv.total))}</td>
                    <td className="px-4 py-3 text-sm text-slate-500">
                      {new Date(inv.createdAt).toLocaleDateString("ar-SA")}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-slate-400">لا توجد فواتير</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, iconColor, iconBg, trend }: {
  title: string;
  value: number;
  icon: React.ElementType;
  iconColor: string;
  iconBg: string;
  trend: "up" | "down";
}) {
  return (
    <div className="stat-card card-hover">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-slate-500 mb-1">{title}</p>
          <p className="text-2xl font-bold text-slate-900">{formatCurrency(value)}</p>
        </div>
        <div className={`w-10 h-10 ${iconBg} rounded-xl flex items-center justify-center`}>
          <Icon className={`w-5 h-5 ${iconColor}`} />
        </div>
      </div>
      <div className="flex items-center gap-1 mt-3">
        {trend === "up" ? (
          <TrendingUp className="w-4 h-4 text-emerald-500" />
        ) : (
          <TrendingDown className="w-4 h-4 text-red-500" />
        )}
        <span className={`text-xs ${trend === "up" ? "text-emerald-600" : "text-red-500"}`}>
          {trend === "up" ? "إيجابي" : "سلبي"}
        </span>
      </div>
    </div>
  );
}

function SummaryRow({ label, value, color, large }: { label: string; value: number; color: string; large?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className={`text-slate-600 ${large ? "text-base font-bold" : "text-sm"}`}>{label}</span>
      <span className={`${color} ${large ? "text-lg" : "text-sm"}`}>{formatCurrency(value)}</span>
    </div>
  );
}
