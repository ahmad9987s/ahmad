import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Plus, Trash2, Edit2, Loader2, X, Wallet, Settings2 } from "lucide-react";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

export default function Expenses() {
  const utils = trpc.useUtils();
  const { data: expenses, isLoading } = trpc.expenses.list.useQuery();
  const { data: expenseTypes } = trpc.expenseTypes.list.useQuery();
  const [showCreate, setShowCreate] = useState(false);
  const [showTypes, setShowTypes] = useState(false);
  const [showAddType, setShowAddType] = useState(false);

  // Form
  const [expenseTypeId, setExpenseTypeId] = useState<number | undefined>();
  const [amount, setAmount] = useState(0);
  const [description, setDescription] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [receiptNumber, setReceiptNumber] = useState("");

  // Type form
  const [typeName, setTypeName] = useState("");
  const [typeDesc, setTypeDesc] = useState("");

  const createExpense = trpc.expenses.create.useMutation({
    onSuccess: () => { utils.expenses.list.invalidate(); utils.dashboard.stats.invalidate(); resetForm(); setShowCreate(false); },
  });

  const createType = trpc.expenseTypes.create.useMutation({
    onSuccess: () => { utils.expenseTypes.list.invalidate(); setShowAddType(false); setTypeName(""); setTypeDesc(""); },
  });

  const deleteExpense = trpc.expenses.delete.useMutation({
    onSuccess: () => { utils.expenses.list.invalidate(); utils.dashboard.stats.invalidate(); },
  });

  function resetForm() {
    setExpenseTypeId(undefined); setAmount(0); setDescription(""); setDate(new Date().toISOString().split("T")[0]); setReceiptNumber("");
  }

  const totalExpenses = expenses?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">المصاريف</h1>
        <div className="flex gap-2">
          <button onClick={() => setShowTypes(true)} className="btn-secondary flex items-center gap-2">
            <Settings2 className="w-4 h-4" /> أنواع المصاريف
          </button>
          <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" /> مصروف جديد
          </button>
        </div>
      </div>

      {/* Total */}
      <div className="stat-card">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
            <Wallet className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <p className="text-sm text-slate-500">إجمالي المصاريف</p>
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(totalExpenses)}</p>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-48"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">التاريخ</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">النوع</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">المبلغ</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الوصف</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-slate-600">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {expenses && expenses.length > 0 ? (
                  expenses.map((e) => (
                    <tr key={e.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm text-slate-600">{e.date}</td>
                      <td className="px-4 py-3 text-sm font-medium text-slate-900">{expenseTypes?.find((t) => t.id === e.expenseTypeId)?.name || "-"}</td>
                      <td className="px-4 py-3 text-sm font-bold text-red-600">{formatCurrency(Number(e.amount))}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{e.description || "-"}</td>
                      <td className="px-4 py-3 text-center">
                        <button onClick={() => { if (confirm("هل أنت متأكد؟")) deleteExpense.mutate({ id: e.id }); }} className="p-1.5 hover:bg-red-100 rounded-lg text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">لا توجد مصاريف</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">مصروف جديد</h2>
              <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">نوع المصروف</label>
                <select value={expenseTypeId || ""} onChange={(e) => setExpenseTypeId(e.target.value ? Number(e.target.value) : undefined)} className="input-field">
                  <option value="">عام</option>
                  {expenseTypes?.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">المبلغ *</label>
                <input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} className="input-field" min="0" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">التاريخ</label>
                <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input-field" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">رقم الإيصال</label>
                <input type="text" value={receiptNumber} onChange={(e) => setReceiptNumber(e.target.value)} className="input-field" placeholder="اختياري" dir="rtl" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">الوصف</label>
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} className="input-field" rows={2} placeholder="اختياري" dir="rtl" />
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowCreate(false)} className="btn-secondary">إلغاء</button>
              <button onClick={() => {
                if (amount <= 0) { alert("الرجاء إدخال مبلغ صحيح"); return; }
                createExpense.mutate({ expenseTypeId, amount, description: description || undefined, date, receiptNumber: receiptNumber || undefined });
              }} disabled={createExpense.isPending} className="btn-primary">
                {createExpense.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Types Modal */}
      {showTypes && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">أنواع المصاريف</h2>
              <div className="flex gap-2">
                <button onClick={() => setShowAddType(true)} className="text-sm text-teal-600 hover:text-teal-700 font-medium">+ نوع جديد</button>
                <button onClick={() => setShowTypes(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
              </div>
            </div>
            <div className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50"><tr><th className="px-3 py-2 text-right font-semibold">الاسم</th><th className="px-3 py-2 text-right font-semibold">الوصف</th><th className="px-3 py-2 text-center font-semibold">الحالة</th></tr></thead>
                  <tbody className="divide-y divide-slate-100">
                    {expenseTypes?.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-50"><td className="px-3 py-2 font-medium">{t.name}</td><td className="px-3 py-2 text-slate-500">{t.description || "-"}</td><td className="px-3 py-2 text-center"><span className={`px-2 py-0.5 rounded-full text-xs ${t.isActive ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{t.isActive ? "نشط" : "معطل"}</span></td></tr>
                    ))}
                    {(!expenseTypes || expenseTypes.length === 0) && <tr><td colSpan={3} className="px-3 py-4 text-center text-slate-400">لا توجد أنواع</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Type Modal */}
      {showAddType && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-md my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900">نوع مصروف جديد</h2>
              <button onClick={() => setShowAddType(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الاسم *</label><input type="text" value={typeName} onChange={(e) => setTypeName(e.target.value)} className="input-field" dir="rtl" /></div>
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الوصف</label><input type="text" value={typeDesc} onChange={(e) => setTypeDesc(e.target.value)} className="input-field" dir="rtl" /></div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowAddType(false)} className="btn-secondary">إلغاء</button>
              <button onClick={() => { if (!typeName.trim()) return; createType.mutate({ name: typeName, description: typeDesc || undefined }); }} disabled={createType.isPending} className="btn-primary">
                {createType.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
