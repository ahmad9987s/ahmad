import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Plus, Trash2, Edit2, Loader2, X, Package } from "lucide-react";

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ar-SA").format(amount) + " ₪";
}

export default function Products() {
  const utils = trpc.useUtils();
  const { data: products, isLoading } = trpc.products.list.useQuery();
  const { data: suppliers } = trpc.suppliers.list.useQuery();
  const [showCreate, setShowCreate] = useState(false);
  const [showEdit, setShowEdit] = useState<number | null>(null);

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [unit, setUnit] = useState("قطعة");
  const [costPrice, setCostPrice] = useState(0);
  const [sellPrice, setSellPrice] = useState(0);
  const [stock, setStock] = useState(0);
  const [supplierId, setSupplierId] = useState<number | undefined>();
  const [barcode, setBarcode] = useState("");

  const createProduct = trpc.products.create.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); resetForm(); setShowCreate(false); },
  });

  const updateProduct = trpc.products.update.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); setShowEdit(null); },
  });

  const deleteProduct = trpc.products.delete.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); },
  });

  function resetForm() {
    setName(""); setCategory(""); setUnit("قطعة"); setCostPrice(0); setSellPrice(0); setStock(0); setSupplierId(undefined); setBarcode("");
  }

  const editProduct = products?.find((p) => p.id === showEdit);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">الأصناف</h1>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> صنف جديد
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-48"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الاسم</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">الفئة</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">سعر التكلفة</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">سعر البيع</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-slate-600">المخزون</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-slate-600">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products && products.length > 0 ? (
                  products.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-slate-900">{p.name}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{p.category || "-"}</td>
                      <td className="px-4 py-3 text-sm text-amber-600">{formatCurrency(Number(p.costPrice))}</td>
                      <td className="px-4 py-3 text-sm text-emerald-600">{formatCurrency(Number(p.sellPrice))}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${Number(p.stock) <= 0 ? "bg-red-100 text-red-600" : Number(p.stock) < 10 ? "bg-orange-100 text-orange-600" : "bg-emerald-100 text-emerald-700"}`}>
                          {p.stock} {p.unit}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => { setShowEdit(p.id); setName(p.name); setCategory(p.category || ""); setUnit(p.unit || "قطعة"); setCostPrice(Number(p.costPrice)); setSellPrice(Number(p.sellPrice)); setStock(Number(p.stock)); setSupplierId(p.supplierId || undefined); setBarcode(p.barcode || ""); }} className="p-1.5 hover:bg-amber-100 rounded-lg text-amber-600">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button onClick={() => { if (confirm("هل أنت متأكد؟")) deleteProduct.mutate({ id: p.id }); }} className="p-1.5 hover:bg-red-100 rounded-lg text-red-500">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">لا توجد أصناف</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">صنف جديد</h2>
              <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الاسم *</label><input type="text" value={name} onChange={(e) => setName(e.target.value)} className="input-field" dir="rtl" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-slate-700 mb-1">الفئة</label><input type="text" value={category} onChange={(e) => setCategory(e.target.value)} className="input-field" placeholder="اختياري" dir="rtl" /></div>
                <div><label className="block text-sm font-medium text-slate-700 mb-1">الوحدة</label><input type="text" value={unit} onChange={(e) => setUnit(e.target.value)} className="input-field" dir="rtl" /></div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div><label className="block text-sm font-medium text-slate-700 mb-1">سعر التكلفة</label><input type="number" value={costPrice} onChange={(e) => setCostPrice(Number(e.target.value))} className="input-field" min="0" /></div>
                <div><label className="block text-sm font-medium text-slate-700 mb-1">سعر البيع</label><input type="number" value={sellPrice} onChange={(e) => setSellPrice(Number(e.target.value))} className="input-field" min="0" /></div>
                <div><label className="block text-sm font-medium text-slate-700 mb-1">المخزون</label><input type="number" value={stock} onChange={(e) => setStock(Number(e.target.value))} className="input-field" min="0" /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-slate-700 mb-1">التاجر</label>
                  <select value={supplierId || ""} onChange={(e) => setSupplierId(e.target.value ? Number(e.target.value) : undefined)} className="input-field">
                    <option value="">بدون</option>
                    {suppliers?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-medium text-slate-700 mb-1">الباركود</label><input type="text" value={barcode} onChange={(e) => setBarcode(e.target.value)} className="input-field" placeholder="اختياري" dir="rtl" /></div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowCreate(false)} className="btn-secondary">إلغاء</button>
              <button onClick={() => { if (!name.trim()) return; createProduct.mutate({ name, category: category || undefined, unit: unit || undefined, costPrice, sellPrice, stock, supplierId, barcode: barcode || undefined }); }} disabled={createProduct.isPending} className="btn-primary">
                {createProduct.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEdit && editProduct && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">تعديل صنف</h2>
              <button onClick={() => setShowEdit(null)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div><label className="block text-sm font-medium text-slate-700 mb-1">الاسم *</label><input type="text" value={name} onChange={(e) => setName(e.target.value)} className="input-field" dir="rtl" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-slate-700 mb-1">الفئة</label><input type="text" value={category} onChange={(e) => setCategory(e.target.value)} className="input-field" dir="rtl" /></div>
                <div><label className="block text-sm font-medium text-slate-700 mb-1">الوحدة</label><input type="text" value={unit} onChange={(e) => setUnit(e.target.value)} className="input-field" dir="rtl" /></div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div><label className="block text-sm font-medium text-slate-700 mb-1">سعر التكلفة</label><input type="number" value={costPrice} onChange={(e) => setCostPrice(Number(e.target.value))} className="input-field" min="0" /></div>
                <div><label className="block text-sm font-medium text-slate-700 mb-1">سعر البيع</label><input type="number" value={sellPrice} onChange={(e) => setSellPrice(Number(e.target.value))} className="input-field" min="0" /></div>
                <div><label className="block text-sm font-medium text-slate-700 mb-1">المخزون</label><input type="number" value={stock} onChange={(e) => setStock(Number(e.target.value))} className="input-field" min="0" /></div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowEdit(null)} className="btn-secondary">إلغاء</button>
              <button onClick={() => { updateProduct.mutate({ id: showEdit, name, category: category || undefined, unit: unit || undefined, costPrice, sellPrice, stock }); }} disabled={updateProduct.isPending} className="btn-primary">
                {updateProduct.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "تحديث"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
