import { useState } from "react";
import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard,
  Receipt,
  ShoppingCart,
  Wallet,
  CreditCard,
  Package,
  Users,
  UserCircle,
  Banknote,
  BarChart3,
  TrendingUp,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Store,
} from "lucide-react";

const menuItems = [
  { path: "/", label: "الرئيسية", icon: LayoutDashboard },
  { path: "/invoices", label: "الفواتير", icon: Receipt },
  { path: "/purchases", label: "المشتريات", icon: ShoppingCart },
  { path: "/expenses", label: "المصاريف", icon: Wallet },
  { path: "/salaries", label: "الرواتب", icon: CreditCard },
  { path: "/debts", label: "الديون", icon: Banknote },
  { path: "/bank-transfers", label: "التحويلات البنكية", icon: BarChart3 },
  { path: "/products", label: "الأصناف", icon: Package },
  { path: "/suppliers", label: "التجار", icon: Store },
  { path: "/profit", label: "الأرباح", icon: TrendingUp },
  { path: "/settings", label: "الإعدادات", icon: Settings },
  { path: "/users", label: "المستخدمين", icon: UserCircle, adminOnly: true },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const location = useLocation();
  const { user, logout, isAdmin } = useAuth();

  const filteredMenu = menuItems.filter((item) => !item.adminOnly || isAdmin);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile overlay */}
      {!sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(true)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 right-0 h-screen bg-slate-900 text-white z-50 transition-all duration-300 flex flex-col
          ${sidebarOpen ? "w-64 translate-x-0" : "w-0 lg:w-16 translate-x-full lg:translate-x-0 overflow-hidden"}`}
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-700">
          {sidebarOpen && (
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-teal-500 rounded-lg flex items-center justify-center">
                <Store className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-lg">ABDO</span>
            </Link>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1.5 rounded-lg hover:bg-slate-700 transition-colors"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
          {filteredMenu.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`sidebar-item ${isActive ? "active" : "text-slate-300 hover:text-white"} ${!sidebarOpen ? "justify-center px-2" : ""}`}
                title={!sidebarOpen ? item.label : undefined}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
                {sidebarOpen && isActive && <ChevronRight className="w-4 h-4 mr-auto" />}
              </Link>
            );
          })}
        </nav>

        {/* User */}
        {user && sidebarOpen && (
          <div className="p-4 border-t border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-teal-600 rounded-full flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user.displayName}</p>
                <p className="text-xs text-slate-400">{user.role === "admin" ? "مدير" : user.role === "manager" ? "مدير" : "كاشير"}</p>
              </div>
              <button
                onClick={logout}
                className="p-1.5 rounded-lg hover:bg-slate-700 transition-colors text-red-400"
                title="تسجيل الخروج"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        <div className="p-4 lg:p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
