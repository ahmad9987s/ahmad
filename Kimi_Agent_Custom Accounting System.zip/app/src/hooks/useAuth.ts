import { useCallback } from "react";
import { trpc } from "@/providers/trpc";

export interface LocalUser {
  id: number;
  username: string;
  displayName: string;
  role: string;
}

export function useAuth() {
  const utils = trpc.useUtils();
  const { data: user, isLoading } = trpc.localAuth.me.useQuery(undefined, {
    retry: false,
    refetchInterval: 10000,
  });

  const logout = useCallback(() => {
    localStorage.removeItem("auth_token");
    utils.localAuth.me.invalidate();
    window.location.reload();
  }, [utils]);

  return {
    user: user as LocalUser | null | undefined,
    isLoading,
    isAuthenticated: !!user,
    isAdmin: user?.role === "admin",
    isManager: user?.role === "admin" || user?.role === "manager",
    logout,
  };
}
