import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  decimal,
  bigint,
  boolean,
  int,
  date,
} from "drizzle-orm/mysql-core";

// ==========================================
// المستخدمين
// ==========================================
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  displayName: varchar("display_name", { length: 100 }).notNull(),
  role: mysqlEnum("role", ["admin", "manager", "cashier"]).default("cashier").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// الإعدادات
// ==========================================
export const settings = mysqlTable("settings", {
  id: serial("id").primaryKey(),
  shopName: varchar("shop_name", { length: 100 }).notNull().default("ABDO"),
  shopAddress: text("shop_address").notNull(),
  shopPhone1: varchar("shop_phone1", { length: 20 }),
  shopPhone2: varchar("shop_phone2", { length: 20 }),
  defaultDiscount: decimal("default_discount", { precision: 5, scale: 2 }).default("0"),
  currency: varchar("currency", { length: 10 }).default("₪"),
  taxRate: decimal("tax_rate", { precision: 5, scale: 2 }).default("0"),
  invoicePrefix: varchar("invoice_prefix", { length: 20 }).default("INV"),
  nextInvoiceNumber: int("next_invoice_number").default(1),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ==========================================
// أنواع المبيعات
// ==========================================
export const saleTypes = mysqlTable("sale_types", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  description: text("description"),
  defaultDiscount: decimal("default_discount", { precision: 5, scale: 2 }).default("0"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// أنواع المصاريف
// ==========================================
export const expenseTypes = mysqlTable("expense_types", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// التجار (الموردين)
// ==========================================
export const suppliers = mysqlTable("suppliers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 100 }),
  address: text("address"),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0"),
  notes: text("notes"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// الأصناف
// ==========================================
export const products = mysqlTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  category: varchar("category", { length: 50 }),
  unit: varchar("unit", { length: 20 }).default("piece"),
  costPrice: decimal("cost_price", { precision: 10, scale: 2 }).default("0"),
  sellPrice: decimal("sell_price", { precision: 10, scale: 2 }).default("0"),
  stock: decimal("stock", { precision: 10, scale: 2 }).default("0"),
  supplierId: bigint("supplier_id", { mode: "number", unsigned: true }),
  barcode: varchar("barcode", { length: 50 }),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// الفواتير
// ==========================================
export const invoices = mysqlTable("invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: varchar("invoice_number", { length: 30 }).notNull().unique(),
  customerName: varchar("customer_name", { length: 100 }),
  customerPhone: varchar("customer_phone", { length: 20 }),
  saleTypeId: bigint("sale_type_id", { mode: "number", unsigned: true }),
  paymentMethod: mysqlEnum("payment_method", ["cash", "bank", "credit"]).default("cash"),
  subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
  discount: decimal("discount", { precision: 12, scale: 2 }).default("0"),
  tax: decimal("tax", { precision: 12, scale: 2 }).default("0"),
  total: decimal("total", { precision: 12, scale: 2 }).notNull(),
  paid: decimal("paid", { precision: 12, scale: 2 }).default("0"),
  remaining: decimal("remaining", { precision: 12, scale: 2 }).default("0"),
  notes: text("notes"),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ==========================================
// بنود الفاتورة
// ==========================================
export const invoiceItems = mysqlTable("invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: bigint("invoice_id", { mode: "number", unsigned: true }).notNull(),
  productId: bigint("product_id", { mode: "number", unsigned: true }),
  productName: varchar("product_name", { length: 100 }),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
  discount: decimal("discount", { precision: 10, scale: 2 }).default("0"),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
});

// ==========================================
// المشتريات
// ==========================================
export const purchases = mysqlTable("purchases", {
  id: serial("id").primaryKey(),
  supplierId: bigint("supplier_id", { mode: "number", unsigned: true }),
  productId: bigint("product_id", { mode: "number", unsigned: true }),
  productName: varchar("product_name", { length: 100 }),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
  total: decimal("total", { precision: 12, scale: 2 }).notNull(),
  paid: decimal("paid", { precision: 12, scale: 2 }).default("0"),
  notes: text("notes"),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// المصاريف
// ==========================================
export const expenses = mysqlTable("expenses", {
  id: serial("id").primaryKey(),
  expenseTypeId: bigint("expense_type_id", { mode: "number", unsigned: true }),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  date: date("date").notNull(),
  receiptNumber: varchar("receipt_number", { length: 50 }),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// الرواتب
// ==========================================
export const salaries = mysqlTable("salaries", {
  id: serial("id").primaryKey(),
  employeeName: varchar("employee_name", { length: 100 }).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  month: varchar("month", { length: 20 }).notNull(),
  year: int("year").notNull(),
  description: text("description"),
  date: date("date").notNull(),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// الديون
// ==========================================
export const debts = mysqlTable("debts", {
  id: serial("id").primaryKey(),
  personName: varchar("person_name", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  paid: decimal("paid", { precision: 12, scale: 2 }).default("0"),
  remaining: decimal("remaining", { precision: 12, scale: 2 }).notNull(),
  type: mysqlEnum("type", ["customer", "supplier", "other"]).default("customer"),
  notes: text("notes"),
  dueDate: date("due_date"),
  isPaid: boolean("is_paid").default(false),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// دفعات الديون
// ==========================================
export const debtPayments = mysqlTable("debt_payments", {
  id: serial("id").primaryKey(),
  debtId: bigint("debt_id", { mode: "number", unsigned: true }).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  paymentDate: date("payment_date").notNull(),
  notes: text("notes"),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// التحويلات البنكية
// ==========================================
export const bankTransfers = mysqlTable("bank_transfers", {
  id: serial("id").primaryKey(),
  type: mysqlEnum("type", ["deposit", "withdraw"]).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  fee: decimal("fee", { precision: 10, scale: 2 }).default("0"),
  netAmount: decimal("net_amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  date: date("date").notNull(),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Setting = typeof settings.$inferSelect;
export type SaleType = typeof saleTypes.$inferSelect;
export type ExpenseType = typeof expenseTypes.$inferSelect;
export type Supplier = typeof suppliers.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type InvoiceItem = typeof invoiceItems.$inferSelect;
export type Purchase = typeof purchases.$inferSelect;
export type Expense = typeof expenses.$inferSelect;
export type Salary = typeof salaries.$inferSelect;
export type Debt = typeof debts.$inferSelect;
export type DebtPayment = typeof debtPayments.$inferSelect;
export type BankTransfer = typeof bankTransfers.$inferSelect;
