import { relations } from "drizzle-orm";
import {
  users,
  saleTypes,
  expenseTypes,
  suppliers,
  products,
  invoices,
  invoiceItems,
  purchases,
  expenses,
  salaries,
  debts,
  debtPayments,
  bankTransfers,
} from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  invoices: many(invoices),
  purchases: many(purchases),
  expenses: many(expenses),
  salaries: many(salaries),
  debts: many(debts),
  bankTransfers: many(bankTransfers),
}));

export const saleTypesRelations = relations(saleTypes, ({ many }) => ({
  invoices: many(invoices),
}));

export const expenseTypesRelations = relations(expenseTypes, ({ many }) => ({
  expenses: many(expenses),
}));

export const suppliersRelations = relations(suppliers, ({ many }) => ({
  products: many(products),
  purchases: many(purchases),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  supplier: one(suppliers, {
    fields: [products.supplierId],
    references: [suppliers.id],
  }),
  invoiceItems: many(invoiceItems),
  purchases: many(purchases),
}));

export const invoicesRelations = relations(invoices, ({ one, many }) => ({
  saleType: one(saleTypes, {
    fields: [invoices.saleTypeId],
    references: [saleTypes.id],
  }),
  createdByUser: one(users, {
    fields: [invoices.createdBy],
    references: [users.id],
  }),
  items: many(invoiceItems),
}));

export const invoiceItemsRelations = relations(invoiceItems, ({ one }) => ({
  invoice: one(invoices, {
    fields: [invoiceItems.invoiceId],
    references: [invoices.id],
  }),
  product: one(products, {
    fields: [invoiceItems.productId],
    references: [products.id],
  }),
}));

export const purchasesRelations = relations(purchases, ({ one }) => ({
  supplier: one(suppliers, {
    fields: [purchases.supplierId],
    references: [suppliers.id],
  }),
  product: one(products, {
    fields: [purchases.productId],
    references: [products.id],
  }),
  createdByUser: one(users, {
    fields: [purchases.createdBy],
    references: [users.id],
  }),
}));

export const expensesRelations = relations(expenses, ({ one }) => ({
  expenseType: one(expenseTypes, {
    fields: [expenses.expenseTypeId],
    references: [expenseTypes.id],
  }),
  createdByUser: one(users, {
    fields: [expenses.createdBy],
    references: [users.id],
  }),
}));

export const salariesRelations = relations(salaries, ({ one }) => ({
  createdByUser: one(users, {
    fields: [salaries.createdBy],
    references: [users.id],
  }),
}));

export const debtsRelations = relations(debts, ({ one, many }) => ({
  payments: many(debtPayments),
  createdByUser: one(users, {
    fields: [debts.createdBy],
    references: [users.id],
  }),
}));

export const debtPaymentsRelations = relations(debtPayments, ({ one }) => ({
  debt: one(debts, {
    fields: [debtPayments.debtId],
    references: [debts.id],
  }),
}));

export const bankTransfersRelations = relations(bankTransfers, ({ one }) => ({
  createdByUser: one(users, {
    fields: [bankTransfers.createdBy],
    references: [users.id],
  }),
}));
