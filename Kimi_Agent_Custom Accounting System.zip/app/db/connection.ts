export { getDb } from "../api/queries/connection";
